'use client';

/**
 * Tiny typed client for the /api/scan/* endpoints.
 * Kept separate from the ScanCapture component so it can be unit-tested.
 */

export interface ScanSessionCreated {
  session: {
    id: string; seller_id: string; skinner_id: string | null;
    category_slug: string | null; product_name: string; status: string;
    coverage_pct: number; scan_quality: string; frame_count: number; selected_frames: number;
    created_at: string;
  };
}

export interface ScanFrameStored {
  frame: {
    id: string; url: string; bytes: number; sequence: number;
    is_keyframe: boolean; viewpoint: Record<string, number>;
  };
}

export async function createScanSession(input: { categorySlug: string | null; productName: string; skinnerId?: string | null; deviceInfo?: Record<string, unknown> }): Promise<ScanSessionCreated> {
  const r = await fetch('/api/scan/session', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Could not start scan session');
  return d as ScanSessionCreated;
}

export async function uploadScanFrame(sessionId: string, blob: Blob, viewpoint: { yawDeg: number; pitchDeg: number; sharpness?: number; brightness?: number; trackerConfidence?: number }, isKeyframe: boolean, sequence: number): Promise<ScanFrameStored> {
  const fd = new FormData();
  fd.append('sessionId', sessionId);
  fd.append('sequence', String(sequence));
  fd.append('isKeyframe', isKeyframe ? '1' : '0');
  fd.append('viewpoint', JSON.stringify(viewpoint));
  fd.append('file', blob, `frame-${sequence}.jpg`);
  const r = await fetch('/api/scan/upload', { method: 'POST', body: fd });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Frame upload failed');
  return d as ScanFrameStored;
}

export async function finalizeCoverage(sessionId: string, coverage: {
  coveragePct: number; scanQuality: 'unknown' | 'low' | 'medium' | 'high';
  coverageMap: Record<string, unknown>; warnings: unknown[];
  selectedFrames: number; frameCount: number;
}): Promise<{ session: Record<string, unknown> }> {
  const r = await fetch('/api/scan/reconstruct', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ sessionId, action: 'finalize', ...coverage }),
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Could not finalize coverage');
  return d;
}

export async function startReconstruction(sessionId: string): Promise<{ job: { jobId: string; sessionId: string; isMock: boolean; providerName: string; status: string } }> {
  const r = await fetch('/api/scan/reconstruct', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ sessionId, action: 'reconstruct' }),
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Could not start reconstruction');
  return d;
}

export async function pollJob(sessionId: string, jobId: string): Promise<{ job: ReconstructionJob }> {
  const r = await fetch(`/api/scan/${sessionId}?what=job&jobId=${encodeURIComponent(jobId)}`, { method: 'GET' });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Could not poll reconstruction');
  return d;
}

export async function getScanStatus(sessionId: string): Promise<{ session: Record<string, unknown>; job: ReconstructionJob | null }> {
  const r = await fetch(`/api/scan/${sessionId}?what=status`, { method: 'GET' });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Could not get scan status');
  return d;
}

export async function discardScan(sessionId: string): Promise<void> {
  await fetch(`/api/scan/${sessionId}`, { method: 'DELETE' });
}

export interface ReconstructionJob {
  jobId: string; sessionId?: string; providerName?: string;
  status: 'QUEUED' | 'RUNNING' | 'SUCCEEDED' | 'FAILED' | 'CANCELLED';
  progress: number; isMock: boolean; assetId: string | null; assetUrl?: string;
  modelUrl?: string; error?: string | null; qualityReport?: Record<string, unknown>;
}
