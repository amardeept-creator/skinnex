import 'server-only';
import { mockProvider } from './mock';
import type { ReconstructionProvider, ProviderName } from './types';

/**
 * Returns the active reconstruction provider based on env vars.
 *
 *   RECONSTRUCTION_PROVIDER = 'mock' | 'tripo3d' | 'luma' | 'meshy' | 'nvidia_omniverse' | 'custom'
 *
 * Real providers should be implemented in their own files (e.g. `tripo3d.ts`) and
 * registered here. They MUST be lazy-imported so missing env vars don't crash the
 * rest of Skinify at boot.
 */

const PROVIDER_NAME: ProviderName = (() => {
  const v = (process.env.RECONSTRUCTION_PROVIDER || 'mock') as ProviderName;
  const allowed: ProviderName[] = ['mock', 'tripo3d', 'luma', 'meshy', 'nvidia_omniverse', 'custom'];
  return allowed.includes(v) ? v : 'mock';
})();

let cached: ReconstructionProvider | null = null;

export function getProvider(): ReconstructionProvider {
  if (cached) return cached;

  if (PROVIDER_NAME === 'mock') { cached = mockProvider; return cached; }

  // Real providers — load lazily so the app still boots without their env vars.
  // Each provider file is responsible for reading its own secrets at call-time,
  // not at import time. This keeps Skinify healthy when the secret is missing.
  try {
    if (PROVIDER_NAME === 'tripo3d') {
      // Example future provider. Uncomment after creating the file:
      // const { tripo3dProvider } = require('./tripo3d'); cached = tripo3dProvider; return cached;
    }
    if (PROVIDER_NAME === 'luma') { /* const { lumaProvider } = require('./luma'); cached = lumaProvider; return cached; */ }
    if (PROVIDER_NAME === 'meshy') { /* const { meshyProvider } = require('./meshy'); cached = meshyProvider; return cached; */ }
    if (PROVIDER_NAME === 'nvidia_omniverse') { /* const { omniverseProvider } = require('./nvidia_omniverse'); cached = omniverseProvider; return cached; */ }
    if (PROVIDER_NAME === 'custom') { /* const { customProvider } = require('./custom'); cached = customProvider; return cached; */ }
  } catch (e) {
    console.warn(`[reconstruction] provider '${PROVIDER_NAME}' failed to load, falling back to mock:`, (e as Error).message);
  }

  // Always fall back to the mock provider. Skinify never hard-fails on missing 3rd-party config.
  cached = mockProvider;
  return cached;
}

export function providerName(): ProviderName { return PROVIDER_NAME; }
export function isMockProvider(): boolean { return PROVIDER_NAME === 'mock' || getProvider().isMock; }
