import 'server-only';
import { sql } from '../db';
import { HttpError } from '../http';
import { shortId } from '../ids';
import { getEntitlement } from '../entitlements';
import { putObject, deleteObject } from '../storage';
import { getProvider } from './';
import { processGlb } from '../glb';
import type { FrameInput } from './types';

/**
 * Scan-session + reconstruction-pipeline orchestration.
 *
 * All steps are additive — none of them touch the existing Skinner wizard,
 * GLB uploader, or ar_assets ingest code path. They only run when the seller
 * picks the new "Scan a physical product" option in the wizard.
 */

export const MAX_FRAMES_PER_SESSION = 240;       // hard ceiling — protects cloud cost
export const MAX_KEYFRAMES_PER_SESSION = 60;     // hard ceiling — what we actually reconstruct from
export const FRAME_MAX_BYTES = 4 * 1024 * 1024;  // 4 MB per frame (large JPEG)

export interface ScanSessionRow {
  id: string; seller_id: string; skinner_id: string | null; category_slug: string | null;
  product_name: string; status: string; coverage_pct: number; scan_quality: string;
  frame_count: number; selected_frames: number; created_at: string;
}

export async function createScanSession(sellerId: string, params: { categorySlug: string | null; productName: string; skinnerId?: string | null; deviceInfo?: Record<string, unknown> }): Promise<ScanSessionRow> {
  const e = await getEntitlement(sellerId);
  if (!e.active) throw new HttpError(402, 'Your subscription is inactive. Renew to scan products.');

  const [row] = await sql`
    insert into scan_sessions (seller_id, skinner_id, category_slug, product_name, status, coverage_pct, scan_quality, device_info)
    values (${sellerId}, ${params.skinnerId ?? null}, ${params.categorySlug}, ${params.productName.slice(0, 200)}, 'SCANNING', 0, 'unknown', ${sql.json((params.deviceInfo || {}) as never)})
    returning id, seller_id, skinner_id, category_slug, product_name, status, coverage_pct, scan_quality, frame_count, selected_frames, created_at`;
  return row as ScanSessionRow;
}

export async function getOwnedScanSession(sellerId: string, sessionId: string): Promise<ScanSessionRow | null> {
  const [row] = await sql`
    select id, seller_id, skinner_id, category_slug, product_name, status, coverage_pct, scan_quality, frame_count, selected_frames, created_at
    from scan_sessions where id = ${sessionId} and seller_id = ${sellerId}`;
  return (row as ScanSessionRow) || null;
}

export async function updateScanCoverage(sellerId: string, sessionId: string, patch: { coveragePct: number; scanQuality: 'unknown' | 'low' | 'medium' | 'high'; coverageMap: Record<string, unknown>; warnings: unknown[]; selectedFrames: number; frameCount: number }) {
  const [row] = await sql`
    update scan_sessions set coverage_pct = ${patch.coveragePct}, scan_quality = ${patch.scanQuality},
      coverage_map = ${sql.json(patch.coverageMap as never)}, warnings = ${sql.json(patch.warnings as never)},
      selected_frames = ${patch.selectedFrames}, frame_count = ${patch.frameCount}, updated_at = now()
    where id = ${sessionId} and seller_id = ${sellerId}
    returning id, status, coverage_pct, scan_quality, frame_count, selected_frames`;
  if (!row) throw new HttpError(404, 'Scan session not found');
  return row;
}

export interface StoredFrame { id: string; url: string; bytes: number; sequence: number; isKeyframe: boolean; viewpoint: FrameInput['viewpoint']; }

/** Stores a single client-uploaded JPEG frame and links it to the session. */
export async function storeScanFrame(sellerId: string, sessionId: string, frame: { sequence: number; bytes: Uint8Array; viewpoint: FrameInput['viewpoint']; isKeyframe: boolean }): Promise<StoredFrame> {
  const session = await getOwnedScanSession(sellerId, sessionId);
  if (!session) throw new HttpError(404, 'Scan session not found');
  if (session.status !== 'SCANNING') throw new HttpError(409, `Cannot add frames to a session in status ${session.status}`);
  if (session.frame_count >= MAX_FRAMES_PER_SESSION) throw new HttpError(413, `Too many frames (max ${MAX_FRAMES_PER_SESSION} per scan).`);
  if (frame.bytes.length > FRAME_MAX_BYTES) throw new HttpError(413, 'Frame too large (max 4 MB).');
  if (frame.bytes.length < 1024) throw new HttpError(422, 'Frame too small — likely corrupt.');

  const key = `scans/${sessionId}/${String(frame.sequence).padStart(4, '0')}-${shortId(4)}.jpg`;
  const { url } = await putObject(key, frame.bytes, 'image/jpeg');
  const [row] = await sql`
    insert into scan_frames (session_id, storage_key, url, mime, bytes, viewpoint, is_keyframe, sequence)
    values (${sessionId}, ${key}, ${url}, 'image/jpeg', ${frame.bytes.length}, ${sql.json(frame.viewpoint as never)}, ${frame.isKeyframe}, ${frame.sequence})
    returning id, url, bytes, sequence, is_keyframe, viewpoint`;
  await sql`update scan_sessions set frame_count = frame_count + 1, updated_at = now() where id = ${sessionId}`;
  return { id: row.id, url: row.url, bytes: row.bytes, sequence: row.sequence, isKeyframe: row.is_keyframe, viewpoint: row.viewpoint };
}

/** Soft-deletes a frame from storage + db. */
export async function deleteScanFrame(sellerId: string, sessionId: string, frameId: string) {
  const [row] = await sql`select f.id, f.url, f.storage_key from scan_frames f
    join scan_sessions s on s.id = f.session_id
    where f.id = ${frameId} and f.session_id = ${sessionId} and s.seller_id = ${sellerId}`;
  if (!row) throw new HttpError(404, 'Frame not found');
  await sql`delete from scan_frames where id = ${frameId}`;
  await deleteObject(row.url);
}

/** Returns a list of frames + the latest session status. */
export async function listScanFrames(sellerId: string, sessionId: string) {
  const session = await getOwnedScanSession(sellerId, sessionId);
  if (!session) throw new HttpError(404, 'Scan session not found');
  const frames = await sql`select id, url, bytes, sequence, is_keyframe, viewpoint from scan_frames where session_id = ${sessionId} order by sequence`;
  return { session, frames: frames as unknown as StoredFrame[] };
}

/** Starts a reconstruction job: submits selected keyframes to the provider and records the job row. */
export async function startReconstruction(sellerId: string, sessionId: string) {
  const session = await getOwnedScanSession(sellerId, sessionId);
  if (!session) throw new HttpError(404, 'Scan session not found');
  if (session.coverage_pct < 35) throw new HttpError(422, 'Coverage is too low to reconstruct. Capture more of the product from different angles.');
  if (session.status !== 'SCANNING') {
    // Allow restarting reconstruction for a session that previously failed.
    const [existing] = await sql`select id, status from reconstruction_jobs where session_id = ${sessionId} order by created_at desc limit 1`;
    if (existing && (existing.status === 'RUNNING' || existing.status === 'QUEUED')) {
      throw new HttpError(409, 'A reconstruction job is already running for this scan.');
    }
  }

  const frames = await sql`select id, url, sequence, is_keyframe, viewpoint from scan_frames where session_id = ${sessionId} and is_keyframe = true order by sequence limit ${MAX_KEYFRAMES_PER_SESSION}`;
  const keyframes: FrameInput[] = (frames as unknown as StoredFrame[]).map(f => ({
    url: absoluteUrl(f.url), sequence: f.sequence, viewpoint: f.viewpoint, isKeyframe: true,
  }));
  if (keyframes.length < 6) throw new HttpError(422, `Need at least 6 keyframes (have ${keyframes.length}). Keep scanning.`);

  // Flip the scan session status — the user has finished capturing.
  await sql`update scan_sessions set status = 'PROCESSING', updated_at = now() where id = ${sessionId}`;

  const provider = getProvider();
  const [jobRow] = await sql`
    insert into reconstruction_jobs (session_id, seller_id, provider, status, progress, is_mock, started_at)
    values (${sessionId}, ${sellerId}, ${provider.name}, 'QUEUED', 0, ${provider.isMock}, now())
    returning id, provider, is_mock`;
  const jobId = jobRow.id as string;

  // Submit to the provider. We swallow provider errors into a FAILED status — the
  // outer flow surfaces this to the user as a friendly "couldn't create a model" screen.
  const input = { jobId, sessionId, categorySlug: session.category_slug, productName: session.product_name, frames: keyframes, coveragePct: session.coverage_pct, scanQuality: session.scan_quality as 'unknown' | 'low' | 'medium' | 'high' };
  let externalJobId = 'pending';
  let providerStatus: 'QUEUED' | 'RUNNING' | 'SUCCEEDED' | 'FAILED' = 'QUEUED';
  let errorMsg: string | null = null;
  try {
    const r = await provider.submit(input);
    externalJobId = r.externalJobId;
    providerStatus = r.status === 'QUEUED' ? 'QUEUED' : 'RUNNING';
  } catch (e) {
    providerStatus = 'FAILED';
    errorMsg = (e as Error).message || 'Provider submit failed';
  }
  await sql`update reconstruction_jobs set external_job_id = ${externalJobId}, status = ${providerStatus}, error = ${errorMsg} where id = ${jobId}`;
  return { jobId, sessionId, isMock: jobRow.is_mock as boolean, providerName: jobRow.provider as string, status: providerStatus };
}

/** Polls a reconstruction job: calls the provider, updates progress, and — on success —
 *  fetches the raw model, validates/optimises it through the existing GLB pipeline,
 *  stores the optimized GLB as an ar_asset, and links it back to the job. */
export async function pollReconstruction(sellerId: string, jobId: string) {
  const [job] = await sql`select j.*, s.category_slug, s.product_name, s.coverage_pct, s.scan_quality, s.seller_id as session_seller_id
    from reconstruction_jobs j join scan_sessions s on s.id = j.session_id
    where j.id = ${jobId} and j.seller_id = ${sellerId}`;
  if (!job) throw new HttpError(404, 'Reconstruction job not found');

  if (job.status === 'SUCCEEDED' || job.status === 'FAILED' || job.status === 'CANCELLED') {
    return { jobId, status: job.status, progress: job.progress, assetId: job.asset_id, isMock: job.is_mock, error: job.error, qualityReport: job.quality_report };
  }

  const provider = getProvider();
  const poll = await provider.poll(job.external_job_id);

  if (poll.status === 'RUNNING' || poll.status === 'QUEUED') {
    await sql`update reconstruction_jobs set status = ${poll.status}, progress = ${poll.progress}, updated_at = now() where id = ${jobId}`;
    return { jobId, status: poll.status, progress: poll.progress, isMock: job.is_mock, assetId: null };
  }
  if (poll.status === 'FAILED') {
    await sql`update reconstruction_jobs set status = 'FAILED', progress = 100, error = ${poll.error || 'Reconstruction failed'}, finished_at = now() where id = ${jobId}`;
    await sql`update scan_sessions set status = 'NEEDS_RESCAN', updated_at = now() where id = ${job.session_id}`;
    return { jobId, status: 'FAILED', progress: 100, error: poll.error || 'Reconstruction failed', isMock: job.is_mock, assetId: null };
  }
  if (poll.status === 'CANCELLED') {
    await sql`update reconstruction_jobs set status = 'CANCELLED', finished_at = now() where id = ${jobId}`;
    return { jobId, status: 'CANCELLED', progress: 100, isMock: job.is_mock, assetId: null };
  }

  // SUCCEEDED — pull the model, optimise through the standard GLB pipeline, store as ar_asset.
  if (!poll.modelUrl) {
    await sql`update reconstruction_jobs set status = 'FAILED', error = 'Provider returned no model URL', finished_at = now() where id = ${jobId}`;
    return { jobId, status: 'FAILED', progress: 100, error: 'Provider returned no model URL', isMock: job.is_mock, assetId: null };
  }

  // Fetch the provider's raw model bytes (could be a GLB, glTF JSON, or OBJ — currently only GLB is supported).
  // Real providers can be plugged in by extending this branch.
  const modelBytes = await fetchProviderModel(poll.modelUrl);
  const ext = (poll.modelFormat || 'glb').toLowerCase();
  if (ext !== 'glb' && ext !== 'gltf') {
    await sql`update reconstruction_jobs set status = 'FAILED', error = 'Unsupported model format: ${ext}. Skinify currently expects GLB output.', finished_at = now() where id = ${jobId}`;
    return { jobId, status: 'FAILED', progress: 100, error: 'Unsupported model format', isMock: job.is_mock, assetId: null };
  }

  const { report, output } = await processGlb(modelBytes);
  if (!report.ok) {
    await sql`update reconstruction_jobs set status = 'FAILED', error = ${report.error || 'GLB validation failed'}, finished_at = now() where id = ${jobId}`;
    await sql`update scan_sessions set status = 'NEEDS_RESCAN', updated_at = now() where id = ${job.session_id}`;
    return { jobId, status: 'FAILED', progress: 100, error: report.error || 'GLB validation failed', isMock: job.is_mock, assetId: null };
  }

  const key = `scans/${job.session_id}/${shortId(8)}.glb`;
  const { url } = await putObject(key, output, 'model/gltf-binary');
  const meta = {
    bbox: report.bbox, triangles: report.triangles, meshes: report.meshes,
    materials: report.materials, textures: report.textures,
    maxTextureSize: report.maxTextureSize, extensions: report.extensions,
    warnings: report.warnings, optimized: report.optimized,
    scan: { sessionId: job.session_id, coverage: job.coverage_pct, scanQuality: job.scan_quality, provider: job.provider, mock: job.is_mock },
  };
  const [asset] = await sql`insert into ar_assets (seller_id, kind, storage_key, url, original_filename, mime, bytes, original_bytes, meta, status)
    values (${sellerId}, 'model', ${key}, ${url}, ${`scan-${job.product_name || 'product'}.glb`}, 'model/gltf-binary', ${output.length}, ${modelBytes.length}, ${sql.json(meta as never)}, 'ready')
    returning id, url, meta`;
  await sql`update reconstruction_jobs set status = 'SUCCEEDED', progress = 100, asset_id = ${asset.id}, quality_report = ${sql.json({ ok: true, triangles: report.triangles, textures: report.textures, bbox: report.bbox, materials: report.materials, warnings: report.warnings } as never)}, external_model_url = ${poll.modelUrl}, finished_at = now() where id = ${jobId}`;
  await sql`update scan_sessions set status = 'READY', updated_at = now() where id = ${job.session_id}`;
  return { jobId, status: 'SUCCEEDED', progress: 100, assetId: asset.id, assetUrl: asset.url, isMock: job.is_mock, qualityReport: asset.meta, modelUrl: asset.url };
}

async function fetchProviderModel(url: string): Promise<Uint8Array> {
  const r = await fetch(url, { redirect: 'follow' });
  if (!r.ok) throw new Error(`Provider model fetch failed: HTTP ${r.status}`);
  const buf = new Uint8Array(await r.arrayBuffer());
  if (buf.length === 0) throw new Error('Provider returned an empty model file.');
  if (buf.length > 50 * 1024 * 1024) throw new Error('Reconstructed model is larger than 50 MB.');
  return buf;
}

function absoluteUrl(maybeUrl: string): string {
  if (/^https?:\/\//.test(maybeUrl)) return maybeUrl;
  const base = (process.env.NEXT_PUBLIC_SITE_URL || (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000')).replace(/\/$/, '');
  return base + maybeUrl;
}
