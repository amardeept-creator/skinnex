'use client';
import './scan.css';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { I } from '@/components/Icons';
import {
  COVERAGE_BINS, MAX_KEYFRAMES, makeCoverageState, recordFrame, binForViewpoint, guidanceMessage, missingSides,
  estimateSharpness, estimateBrightness, estimateMotion,
  type CoverageState, type ScanWarning,
} from '@/lib/client/scan/coverage';
import {
  createScanSession, uploadScanFrame, finalizeCoverage, startReconstruction, discardScan, pollJob,
  type ReconstructionJob,
} from '@/lib/client/scan/api';

export interface ScanResult {
  sessionId: string;
  jobId: string;
  isMock: boolean;
  providerName: string;
  assetId: string | null;
  assetUrl?: string;
  modelUrl?: string;
  coveragePct: number;
  scanQuality: 'unknown' | 'low' | 'medium' | 'high';
}

export interface ScanCaptureProps {
  /** Skinned category — used by the mock provider to pick a seed model. */
  categorySlug: string | null;
  productName: string;
  skinnerId?: string | null;
  /** Called when the user finishes scanning and reconstruction has been started. */
  onReconstructing: (info: { sessionId: string; jobId: string; isMock: boolean; providerName: string }) => void;
  /** Called when the user backs out before scanning (no session created yet). */
  onCancel: () => void;
  /** Called when the scan completes (model ready). */
  onComplete: (result: ScanResult) => void;
}

type Phase = 'intro' | 'requesting' | 'scanning' | 'paused' | 'finalizing' | 'reconstructing' | 'failed' | 'done';

export function ScanCapture({ categorySlug, productName, skinnerId, onCancel, onReconstructing, onComplete }: ScanCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const prevImageDataRef = useRef<ImageData | null>(null);
  const orientRef = useRef<{ yawDeg: number; pitchDeg: number }>({ yawDeg: 0, pitchDeg: 0 });
  const orientPermRef = useRef<'unknown' | 'requested' | 'granted' | 'denied'>('unknown');
  const rafRef = useRef<number | null>(null);
  const lastCaptureAtRef = useRef(0);
  const sessionRef = useRef<string | null>(null);
  const coverageRef = useRef<CoverageState>(makeCoverageState());
  const unloadingRef = useRef(false);

  const [phase, setPhase] = useState<Phase>('intro');
  const [err, setErr] = useState<string | null>(null);
  const [coverage, setCoverage] = useState<CoverageState>(makeCoverageState());
  const [warnings, setWarnings] = useState<ScanWarning[]>([]);
  const [guidance, setGuidance] = useState<{ primary: string; hint?: string }>({ primary: 'Start moving around the product' });
  const [uploading, setUploading] = useState(false);
  const [job, setJob] = useState<ReconstructionJob | null>(null);
  const [flash, setFlash] = useState(false);

  /* ---------- device orientation (yaw/pitch) ---------- */
  useEffect(() => {
    const onOrient = (e: DeviceOrientationEvent) => {
      // iOS uses webkitCompassHeading; Android uses alpha (counter-clockwise from north).
      // We treat 0° as "front of product" — actual compass direction doesn't matter.
      const compass = (e as unknown as { webkitCompassHeading?: number }).webkitCompassHeading;
      let yaw: number;
      if (typeof compass === 'number' && !Number.isNaN(compass)) yaw = compass;
      else if (e.alpha != null) yaw = 360 - e.alpha;     // Android: alpha is counter-clockwise
      else yaw = orientRef.current.yawDeg;
      const pitch = e.beta ?? orientRef.current.pitchDeg;    // -180..180 (front face down/up)
      orientRef.current = { yawDeg: yaw, pitchDeg: pitch ?? 0 };
    };
    window.addEventListener('deviceorientation', onOrient);
    return () => window.removeEventListener('deviceorientation', onOrient);
  }, []);

  const requestOrientation = useCallback(async () => {
    const D = typeof DeviceOrientationEvent !== 'undefined' ? (DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> }) : undefined;
    if (D && typeof D.requestPermission === 'function') {
      try {
        orientPermRef.current = 'requested';
        const r = await D.requestPermission();
        orientPermRef.current = r === 'granted' ? 'granted' : 'denied';
        return r === 'granted';
      } catch { orientPermRef.current = 'denied'; return false; }
    }
    orientPermRef.current = 'granted';
    return true;   // Android Chrome doesn't need explicit permission.
  }, []);

  /* ---------- camera start/stop ---------- */
  const stopCamera = useCallback(() => {
    if (streamRef.current) { streamRef.current.getTracks().forEach(t => t.stop()); streamRef.current = null; }
    if (videoRef.current) videoRef.current.srcObject = null;
  }, []);

  const startCamera = useCallback(async () => {
    setErr(null);
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setErr('Camera not available in this browser. Open this page on a phone over HTTPS.'); return false;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      return true;
    } catch (e) {
      const name = (e as Error)?.name || '';
      if (name === 'NotAllowedError') setErr('Camera access is off. Allow camera access in your browser settings and try again.');
      else if (name === 'NotFoundError') setErr('No camera found. Connect a camera or move to a different device.');
      else if (name === 'NotReadableError') setErr('The camera is in use by another app. Close it and try again.');
      else setErr((e as Error).message || 'Could not open the camera.');
      return false;
    }
  }, []);

  /* ---------- frame capture loop ---------- */
  const captureFrame = useCallback(async (force = false): Promise<void> => {
    const video = videoRef.current; const canvas = canvasRef.current;
    if (!video || !canvas || !video.videoWidth) return;
    const now = performance.now();
    if (!force && now - lastCaptureAtRef.current < 700) return;   // ~1.4 fps capture rate
    lastCaptureAtRef.current = now;

    const w = video.videoWidth, h = video.videoHeight;
    canvas.width = 480; canvas.height = Math.round(480 * h / w);   // downsample for upload speed
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const sharpness = estimateSharpness(ctx, canvas.width, canvas.height);
    const brightness = estimateBrightness(ctx, canvas.width, canvas.height);
    const { motion, frame: nextFrame } = estimateMotion(prevImageDataRef.current, ctx, canvas.width, canvas.height);
    prevImageDataRef.current = nextFrame;

    const prev = coverageRef.current;
    const { yawDeg, pitchDeg } = orientRef.current;
    const updated = recordFrame(prev, { yawDeg, pitchDeg, sharpness, brightness, motionScore: motion });
    coverageRef.current = updated;
    setCoverage(updated);
    setWarnings(updated.warnings);
    setGuidance(guidanceMessage(updated));

    // Upload only accepted keyframes (cost control).
    const last = updated.keyframes[updated.keyframes.length - 1];
    if (last && last.sequence === updated.frameCount - 1 && sessionRef.current) {
      const seq = updated.frameCount - 1;
      setUploading(true);
      try {
        const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(b => resolve(b), 'image/jpeg', 0.78));
        if (blob) await uploadScanFrame(sessionRef.current, blob, { yawDeg: last.yawDeg, pitchDeg: last.pitchDeg, sharpness: last.sharpness, brightness: last.brightness, trackerConfidence: motion }, true, seq);
      } catch (e) {
        // Soft-fail: the upload will be retried implicitly on the next keyframe.
        console.warn('[scan] frame upload failed', (e as Error).message);
      } finally { setUploading(false); }
    }
  }, []);

  useEffect(() => {
    if (phase !== 'scanning') return;
    const tick = () => { captureFrame(false).catch(() => {}); rafRef.current = window.setTimeout(tick, 350) as unknown as number; };
    rafRef.current = window.setTimeout(tick, 350) as unknown as number;
    return () => { if (rafRef.current) window.clearTimeout(rafRef.current); rafRef.current = null; };
  }, [phase, captureFrame]);

  /* ---------- scan start / cancel ---------- */
  const beginScan = useCallback(async () => {
    setPhase('requesting');
    setErr(null);
    const orientOk = await requestOrientation();
    if (!orientOk) {
      setErr('Motion-and-orientation permission was denied. Scan still works but coverage guidance is approximate.');
    }
    const camOk = await startCamera();
    if (!camOk) { setPhase('intro'); return; }
    try {
      const { session } = await createScanSession({
        categorySlug, productName, skinnerId: skinnerId ?? null,
        deviceInfo: { ua: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown', orientationPermission: orientPermRef.current },
      });
      sessionRef.current = session.id;
      coverageRef.current = makeCoverageState();
      setCoverage(coverageRef.current);
      setPhase('scanning');
    } catch (e) {
      setErr((e as Error).message || 'Could not start a scan session.');
      setPhase('intro');
      stopCamera();
    }
  }, [categorySlug, productName, skinnerId, requestOrientation, startCamera, stopCamera]);

  const cancelScan = useCallback(async () => {
    if (unloadingRef.current) return;
    if (sessionRef.current) { try { await discardScan(sessionRef.current); } catch { /* ignore */ } sessionRef.current = null; }
    stopCamera();
    onCancel();
  }, [onCancel, stopCamera]);

  /* ---------- finalize + start reconstruction ---------- */
  const completeScan = useCallback(async () => {
    if (!sessionRef.current) return;
    setPhase('finalizing');
    setFlash(true); setTimeout(() => setFlash(false), 350);
    try {
      const c = coverageRef.current;
      await finalizeCoverage(sessionRef.current, {
        coveragePct: c.coveragePct,
        scanQuality: c.scanQuality,
        coverageMap: { bins: c.bins, yawHistogram: c.yawHistogram, pitchHistogram: c.pitchHistogram, keyframes: c.keyframes.length },
        warnings: c.warnings,
        selectedFrames: c.keyframes.length,
        frameCount: c.frameCount,
      });
      stopCamera();
      setPhase('reconstructing');
      const r = await startReconstruction(sessionRef.current);
      const jobStatus = (r.job.status as ReconstructionJob['status']) || 'RUNNING';
      setJob({ jobId: r.job.jobId, sessionId: r.job.sessionId, isMock: r.job.isMock, providerName: r.job.providerName, status: jobStatus, progress: 0, assetId: null });
      onReconstructing({ sessionId: r.job.sessionId, jobId: r.job.jobId, isMock: r.job.isMock, providerName: r.job.providerName });
    } catch (e) {
      setErr((e as Error).message || 'Could not finalize the scan.');
      setPhase('scanning');
    }
  }, [onReconstructing, stopCamera]);

  /* ---------- poll reconstruction until done ---------- */
  useEffect(() => {
    if (phase !== 'reconstructing' || !sessionRef.current || !job) return;
    let dead = false;
    const poll = async () => {
      try {
        const { job: j } = await pollJob(sessionRef.current!, job.jobId);
        if (dead) return;
        setJob(j);
        if (j.status === 'SUCCEEDED') {
          const c = coverageRef.current;
          setPhase('done');
          onComplete({
            sessionId: sessionRef.current!, jobId: job.jobId, isMock: j.isMock, providerName: job.providerName || 'mock',
            assetId: j.assetId, assetUrl: j.assetUrl, modelUrl: j.modelUrl,
            coveragePct: c.coveragePct, scanQuality: c.scanQuality,
          });
        } else if (j.status === 'FAILED' || j.status === 'CANCELLED') {
          setErr(j.error || 'Reconstruction failed.');
          setPhase('failed');
        } else {
          window.setTimeout(poll, 1200);
        }
      } catch (e) {
        if (!dead) { setErr((e as Error).message || 'Could not poll the reconstruction job.'); setPhase('failed'); }
      }
    };
    window.setTimeout(poll, 800);
    return () => { dead = true; };
  }, [phase, job, onComplete]);

  /* ---------- pause / resume when tab is hidden ---------- */
  useEffect(() => {
    const vis = () => { if (document.hidden && phase === 'scanning') { setPhase('paused'); } };
    document.addEventListener('visibilitychange', vis);
    return () => document.removeEventListener('visibilitychange', vis);
  }, [phase]);
  useEffect(() => {
    const unload = () => { unloadingRef.current = true; stopCamera(); };
    window.addEventListener('pagehide', unload);
    return () => { window.removeEventListener('pagehide', unload); stopCamera(); };
  }, [stopCamera]);

  const missing = useMemo(() => missingSides(coverage), [coverage]);
  const pct = coverage.coveragePct;
  const canComplete = pct >= 35;

  /* ---------- render ---------- */
  if (phase === 'intro') {
    return (
      <div className="scan-root scan-screen">
        <button className="scan-back" onClick={onCancel} aria-label="Back"><I.back size={20} /></button>
        <div className="scan-card">
          <div className="scan-orb"><I.camera size={36} /></div>
          <h1>Scan your product</h1>
          <p className="muted">Point your camera at the product, then walk around it slowly. Skinify will guide you and stop when coverage is good enough to build a 3D model.</p>
          <ul className="scan-bullets">
            <li><I.check size={14} /> Good light · even, not harsh</li>
            <li><I.check size={14} /> Plain background helps separation</li>
            <li><I.check size={14} /> Product still · you move around it</li>
            <li><I.check size={14} /> Capture front, sides, back, top</li>
          </ul>
          <button className="btn btn-xl btn-iris btn-block" onClick={beginScan}><I.camera size={20} /> Start scan</button>
          <p className="tiny faint">Frames are processed on your device. Only useful keyframes are uploaded.</p>
        </div>
      </div>
    );
  }

  if (phase === 'requesting') {
    return (
      <div className="scan-root scan-screen">
        <div className="scan-card">
          <div className="scan-orb"><span className="spinner-dot" /></div>
          <h2>Opening the camera…</h2>
          <p className="muted">If your browser asks, choose <b>Allow</b> for camera and motion sensors.</p>
          <button className="btn btn-ghost" onClick={cancelScan}>Cancel</button>
        </div>
      </div>
    );
  }

  if (phase === 'paused') {
    return (
      <div className="scan-root scan-screen">
        <div className="scan-card">
          <div className="scan-orb"><I.camera size={28} /></div>
          <h2>Camera paused</h2>
          <p className="muted">We turned the camera off while you were away.</p>
          <button className="btn btn-xl btn-iris btn-block" onClick={async () => { const ok = await startCamera(); if (ok) setPhase('scanning'); }}>Resume</button>
          <button className="btn btn-ghost btn-block" onClick={cancelScan}>Discard scan</button>
        </div>
      </div>
    );
  }

  // Scanning / finalizing / reconstructing / failed / done share the camera background.
  return (
    <div className="scan-root">
      <video ref={videoRef} className="scan-video" autoPlay playsInline muted />
      <canvas ref={canvasRef} hidden />

      {/* Top bar */}
      <div className="scan-top">
        <button className="scan-icon-btn" onClick={cancelScan} aria-label="Cancel scan"><I.close size={20} /></button>
        <div className="scan-pill"><I.cube size={14} /> {productName || 'Product'} scan</div>
        <span className="spacer" />
        <span className="scan-pill small">{coverage.keyframes.length}/{MAX_KEYFRAMES} keyframes</span>
      </div>

      {/* Center reticle + coverage ring */}
      <div className="scan-reticle-wrap">
        <div className="scan-reticle">
          <svg viewBox="0 0 120 120" className="scan-ring">
            <circle cx="60" cy="60" r="54" />
            <circle cx="60" cy="60" r="54" className="scan-ring-fill" style={{ strokeDasharray: `${(pct / 100) * (2 * Math.PI * 54)} ${2 * Math.PI * 54}` }} />
          </svg>
          <div className="scan-reticle-center">
            <b className="scan-pct">{pct}<span>%</span></b>
            <span className="scan-pct-label">Coverage</span>
          </div>
          <div className="scan-silhouette"><I.cube size={42} /></div>
        </div>
      </div>

      {/* Coverage map — 6 cardinal bins */}
      <div className="scan-cov-map">
        {COVERAGE_BINS.map(b => {
          const active = coverage.bins[b];
          return (
            <div key={b} className={`scan-cov-cell${active ? ' on' : ''}${missing.includes(b) && pct >= 30 && pct < 95 ? ' want' : ''}`}>
              <span className="dot" />{b}
            </div>
          );
        })}
      </div>

      {/* Warnings */}
      {warnings.length > 0 && (
        <div className="scan-warnings">
          {warnings.map((w, i) => (
            <div key={i} className={`scan-warn scan-warn-${w.kind.includes('lighting') ? 'light' : w.kind.includes('motion') ? 'motion' : 'sharp'}`}>
              <I.shield size={14} /> {w.msg}
            </div>
          ))}
        </div>
      )}

      {/* Guidance */}
      <div className="scan-guidance">
        <b>{guidance.primary}</b>
        {guidance.hint && <span className="small muted">{guidance.hint}</span>}
        {uploading && <span className="tiny faint"><span className="spinner-dot" /> uploading keyframe…</span>}
      </div>

      {/* Bottom controls */}
      <div className="scan-bottom">
        <button className="btn btn-ghost scan-btn-secondary" onClick={cancelScan}>Cancel</button>
        <button className="btn btn-iris btn-lg scan-shutter" onClick={completeScan} disabled={!canComplete}>
          {canComplete ? <><I.check size={18} /> Create 3D Skinner</> : `Need ${35 - pct}% more coverage`}
        </button>
      </div>

      {flash && <div className="scan-flash" />}

      {(phase === 'finalizing' || phase === 'reconstructing' || phase === 'failed' || phase === 'done') && (
        <div className="scan-overlay">
          {phase === 'finalizing' && (<div className="scan-card scan-card-sm"><div className="scan-orb"><span className="spinner-dot" /></div><h2>Finalizing your scan…</h2><p className="muted">Selecting the best keyframes and starting the 3D pipeline.</p></div>)}
          {phase === 'reconstructing' && (<div className="scan-card scan-card-sm">
            <div className="scan-orb"><span className="spinner-dot" /></div>
            <h2>Creating your Skinner…</h2>
            <div className="scan-progress-bar"><i style={{ width: `${job?.progress ?? 0}%` }} /></div>
            <p className="muted">{job?.isMock ? 'Prototype reconstruction (mock provider). Real photogrammetry can be plugged in by setting RECONSTRUCTION_PROVIDER.' : `Reconstructing with ${job?.providerName || 'provider'}…`}</p>
          </div>)}
          {phase === 'failed' && (<div className="scan-card scan-card-sm">
            <div className="scan-orb scan-orb-err"><I.close size={28} /></div>
            <h2>We couldn’t create a reliable 3D model from this scan.</h2>
            <p className="muted">{err || 'Try again with better lighting and more coverage.'}</p>
            <ul className="scan-bullets small">
              <li>Insufficient coverage: capture all six sides</li>
              <li>Reflective or transparent surfaces are hard</li>
              <li>Poor lighting or motion blur</li>
              <li>Product too small or background too busy</li>
            </ul>
            <button className="btn btn-iris btn-block" onClick={async () => { if (sessionRef.current) { try { await discardScan(sessionRef.current); } catch {} } sessionRef.current = null; setPhase('intro'); setErr(null); setJob(null); coverageRef.current = makeCoverageState(); setCoverage(coverageRef.current); }}>Try again</button>
            <button className="btn btn-ghost btn-block" onClick={cancelScan}>Discard scan</button>
          </div>)}
        </div>
      )}
    </div>
  );
}
