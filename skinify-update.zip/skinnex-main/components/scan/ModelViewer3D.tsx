'use client';
import './scan.css';
import { useEffect, useRef, useState, useCallback } from 'react';
import { I } from '@/components/Icons';

/**
 * Google <model-viewer> integration — the "View in your space" experience.
 *
 * Loads Google's model-viewer web component (~50 KB gzipped) from the official
 * unpkg CDN. We lazy-load the script only when this component is first mounted,
 * so the rest of Skinify stays unaffected.
 *
 * AR routing:
 *   - Android + Chrome ≥ 86 → Scene Viewer (ARCore) via model-viewer's ar-modes="scene-viewer quick-look".
 *   - iOS ≥ 12 + Safari → Quick Look (uses the .usdz URL if provided; model-viewer auto-falls back).
 *   - Desktop → interactive 3D viewer (rotate/zoom/pan/fullscreen) only; the AR button is hidden.
 *
 * model-viewer gracefully handles platform detection. We expose a single primary
 * "View in your space" button that the component renders natively when AR is
 * available, and hide it when it isn't.
 */

let mvLoader: Promise<void> | null = null;
function loadModelViewer(): Promise<void> {
  if (typeof window === 'undefined') return Promise.resolve();
  if (customElements && customElements.get('model-viewer')) return Promise.resolve();
  if (mvLoader) return mvLoader;
  mvLoader = new Promise<void>((resolve, reject) => {
    const s = document.createElement('script');
    s.type = 'module';
    s.src = 'https://unpkg.com/@google/model-viewer@3.5.1/dist/model-viewer.min.js';
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('Could not load the 3D viewer. Check your connection.'));
    document.head.appendChild(s);
  });
  return mvLoader;
}

export interface ModelViewer3DProps {
  /** GLB model URL (Skinify-hosted). */
  modelUrl: string;
  /** Optional USDZ model URL for iOS Quick Look. If absent, model-viewer auto-converts. */
  usdzUrl?: string | null;
  /** Real-world size of the model in metres (for AR placement scale hint). */
  scaleMeters?: number;
  productName?: string;
  autoRotate?: boolean;
  /** Compact mode: hides the info card and toolbar (used in inline embeds). */
  compact?: boolean;
  /** Information to surface in the quality card (null = hide card). */
  info?: { triangles?: number; textures?: number; bytes?: number; warnings?: string[]; isMock?: boolean } | null;
}

export function ModelViewer3D({ modelUrl, usdzUrl, scaleMeters = 0.3, productName = 'Product', autoRotate = true, compact = false, info = null }: ModelViewer3DProps) {
  const ref = useRef<HTMLElement | null>(null);
  const [ready, setReady] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [arSupported, setArSupported] = useState<boolean | null>(null);
  const [fullscreen, setFullscreen] = useState(false);

  // Detect AR support — never show the AR button on desktop / unsupported browsers.
  useEffect(() => {
    let dead = false;
    (async () => {
      try {
        await loadModelViewer();
        if (dead) return;
        setReady(true);
        // model-viewer exposes ar-placement support asynchronously via the `ar-status` event.
        // We check after a tick if the AR slot is rendered.
        const mv = ref.current;
        if (mv) {
          const onArStatus = (e: Event) => {
            const status = (e as CustomEvent<string>).detail;
            setArSupported(status === 'session-started' || status === 'object-placed' || status === 'failed' ? false : status !== 'not-AR-capable');
          };
          mv.addEventListener('ar-status', onArStatus as EventListener);
          // Hint: model-viewer will hide its AR button automatically if AR isn't supported.
        }
      } catch (e) {
        if (!dead) setErr((e as Error).message);
      }
    })();
    return () => { dead = true; };
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (!ref.current) return;
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else ref.current.requestFullscreen?.().catch(() => {});
  }, []);
  useEffect(() => {
    const onFs = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFs);
    return () => document.removeEventListener('fullscreenchange', onFs);
  }, []);

  const reset = useCallback(() => {
    const mv = ref.current as unknown as { cameraOrbit?: string; jumpCameraToGoal?: () => void } | null;
    if (mv && typeof mv.jumpCameraToGoal === 'function') {
      mv.cameraOrbit = '0deg 75deg 105%';
      mv.jumpCameraToGoal();
    }
  }, []);

  return (
    <div className="mv-root">
      {ready ? (
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        <model-viewer
          ref={ref as any}
          src={modelUrl}
          ios-src={usdzUrl || undefined}
          ar
          ar-modes="scene-viewer quick-look webxr"
          ar-scale="fixed"
          camera-controls
          auto-rotate={autoRotate}
          auto-rotate-delay={4000}
          shadow-intensity="1"
          exposure="1"
          environment-image="neutral"
          skybox-image={undefined}
          poster={undefined}
          interaction-prompt="auto"
          interaction-prompt-style="wiggle"
          camera-orbit="0deg 75deg 105%"
          field-of-view="30deg"
          style={{ width: '100%', height: '100%', minHeight: compact ? 320 : 460, borderRadius: 'var(--r-lg)' }}
          aria-label={`${productName} — 3D model viewer`}
        >
          {/* model-viewer's built-in AR button slot */}
          <button slot="ar-button" className="mv-ar-btn" aria-label={`View ${productName} in your space`}>
            <I.cube size={18} /> View in your space
          </button>
          <div slot="poster" className="mv-loading" aria-hidden="true">
            <span className="row small muted"><span className="spinner-dot" />Loading 3D…</span>
          </div>
        </model-viewer>
      ) : (
        <div className="mv-loading">
          {err ? <div className="small" style={{ color: 'var(--danger)', maxWidth: 280, textAlign: 'center' }}>{err}</div> : <span className="row small muted"><span className="spinner-dot" />Loading viewer…</span>}
        </div>
      )}

      <div className="mv-badges">
        <span className="badge badge-ar"><i />3D · drag to rotate{arSupported === false ? ' · AR unavailable on this device' : ''}</span>
        {info?.isMock && <span className="badge badge-warn">Prototype model</span>}
      </div>

      {!compact && (
        <>
          <div className="mv-toolbar">
            <button className="btn btn-soft btn-sm" onClick={reset} aria-label="Reset view"><I.refresh size={16} /></button>
            <button className="btn btn-soft btn-sm" onClick={toggleFullscreen} aria-label={fullscreen ? 'Exit fullscreen' : 'Fullscreen'}>{fullscreen ? <I.close size={16} /> : <I.grid size={16} />}</button>
            {arSupported !== false && (
              // The native AR button is auto-positioned by model-viewer. We add a duplicate toolbar
              // hint that scrolls into view on mobile — but only when AR is supported.
              <a className="btn btn-iris btn-sm" href={`#view`} onClick={(e) => { e.preventDefault(); (ref.current as unknown as { activateAR?: () => void } | null)?.activateAR?.(); }}><I.cube size={16} /> View in your space</a>
            )}
          </div>

          {info && (
            <div className="mv-info">
              <div className="mv-info-card">
                <b className="small">{productName}</b>
                <div className="tiny muted" style={{ marginTop: 6 }}>3D model · AR-ready</div>
                <div style={{ marginTop: 8 }}>
                  {info.triangles != null && <div className="tiny"><span className="muted">Triangles</span><b>{info.triangles.toLocaleString()}</b></div>}
                  {info.textures != null && <div className="tiny"><span className="muted">Textures</span><b>{info.textures}</b></div>}
                  {info.bytes != null && <div className="tiny"><span className="muted">File size</span><b>{formatBytesLocal(info.bytes)}</b></div>}
                  <div className="tiny"><span className="muted">AR scale</span><b>{(scaleMeters * 100).toFixed(0)} cm</b></div>
                </div>
                {info.warnings && info.warnings.length > 0 && (
                  <div style={{ marginTop: 8 }}>
                    {info.warnings.map((w, i) => <div key={i} className="tiny" style={{ color: 'var(--warn)', marginTop: 2 }}>⚠ {w}</div>)}
                  </div>
                )}
                {info.isMock && <div className="tiny" style={{ color: 'var(--warn)', marginTop: 6 }}>Prototype: produced by the mock reconstruction provider.</div>}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function formatBytesLocal(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1048576) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1048576).toFixed(1)} MB`;
}
