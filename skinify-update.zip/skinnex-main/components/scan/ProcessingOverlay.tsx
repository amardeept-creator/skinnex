'use client';
import './scan.css';
import { useEffect, useMemo, useState } from 'react';
import { I } from '@/components/Icons';
import type { ReconstructionJob } from '@/lib/client/scan/api';

export interface ProcessingOverlayProps {
  isMock: boolean;
  providerName: string;
  job: ReconstructionJob | null;
  coveragePct: number;
  productName: string;
  /** Called when the job has SUCCEEDED and the user taps "View 3D". */
  onView: () => void;
  /** Called when the user wants to abandon and start a new scan. */
  onRescan: () => void;
}

/** Beautiful processing screen shown after the user finishes scanning.
 *  Surfaces a checklist of pipeline stages with live status. */
export function ProcessingOverlay({ isMock, providerName, job, coveragePct, productName, onView, onRescan }: ProcessingOverlayProps) {
  const progress = job?.progress ?? 0;
  const [tick, setTick] = useState(0);
  useEffect(() => { const t = window.setInterval(() => setTick(v => v + 1), 700); return () => window.clearInterval(t); }, []);

  const stages = useMemo(() => ([
    { key: 'scan', label: 'Scan captured', detail: `${coveragePct}% coverage` },
    { key: 'coverage', label: 'Coverage verified', detail: 'Keyframes selected' },
    { key: 'reconstruct', label: 'Product reconstructed', detail: isMock ? 'Prototype provider (mock)' : `Provider: ${providerName}` },
    { key: 'texture', label: 'Texture & materials generated', detail: 'PBR pipeline' },
    { key: 'optimize', label: '3D model optimized', detail: 'Meshopt + prune' },
    { key: 'validate', label: 'AR compatibility checked', detail: 'GLB validated' },
  ]), [coveragePct, isMock, providerName]);

  // Map provider progress to stage transitions.
  const stageIdx = progress >= 100 ? stages.length
    : progress >= 85 ? 5
    : progress >= 65 ? 4
    : progress >= 45 ? 3
    : progress >= 25 ? 2
    : progress >= 5 ? 1 : 0;

  const failed = job?.status === 'FAILED' || job?.status === 'CANCELLED';

  return (
    <div className="scan-root scan-screen">
      <div className="scan-card">
        <div className={`scan-orb${failed ? ' scan-orb-err' : ''}`}>
          {failed ? <I.close size={30} /> : progress >= 100 ? <I.check size={30} /> : <span className="spinner-dot" />}
        </div>

        {failed ? (
          <>
            <h2>We couldn’t create a reliable 3D model from this scan.</h2>
            <p className="muted">{job?.error || 'Reconstruction failed. Try again with better lighting and more coverage.'}</p>
            <ul className="scan-bullets small">
              <li><I.shield size={14} /> Insufficient coverage — capture all six sides</li>
              <li><I.shield size={14} /> Reflective or transparent surfaces are hard</li>
              <li><I.shield size={14} /> Poor lighting or motion blur</li>
              <li><I.shield size={14} /> Product too small or background too busy</li>
            </ul>
            <button className="btn btn-iris btn-block" onClick={onRescan}><I.refresh size={16} /> Try again</button>
          </>
        ) : progress >= 100 ? (
          <>
            <span className="badge badge-success" style={{ alignSelf: 'center' }}>{isMock ? 'Prototype ready' : 'Skinner ready'}</span>
            <h2>Your Skinner is ready</h2>
            <p className="muted">{productName || 'Your product'} has been turned into a 3D model you can preview and place in your space.</p>
            {isMock && <p className="tiny faint">Prototype result — the mock provider picked a reference SKINIFY base model. Connect a real reconstruction provider with RECONSTRUCTION_PROVIDER to produce a true scan-based model.</p>}
            <div className="row" style={{ flexWrap: 'wrap', justifyContent: 'center' }}>
              <button className="btn btn-iris btn-lg" onClick={onView}><I.cube size={18} /> View 3D</button>
              <button className="btn btn-ghost" onClick={onRescan}>Rescan</button>
            </div>
          </>
        ) : (
          <>
            <h2>Creating your Skinner…</h2>
            <ul className="scan-checklist">
              {stages.map((s, i) => {
                const done = i < stageIdx;
                const active = i === stageIdx;
                return (
                  <li key={s.key} className={done ? 'done' : active ? 'active' : ''}>
                    <span className="scan-check">
                      {done ? <I.check size={12} /> : active ? <span className="spinner-dot" /> : <span className="dot-empty" />}
                    </span>
                    <div>
                      <b>{s.label}</b>
                      <span className="tiny muted">{s.detail}</span>
                    </div>
                  </li>
                );
              })}
            </ul>
            <div className="scan-progress-bar"><i style={{ width: `${progress}%` }} /></div>
            <p className="tiny faint">{progress}% · {isMock ? 'prototype reconstruction (mock)' : providerName}</p>
            {tick > 0 && <span className="sr-only" aria-live="polite">{progress}% complete</span>}
          </>
        )}
      </div>
    </div>
  );
}
