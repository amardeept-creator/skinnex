import { z } from 'zod';
import { json, handle, assertSameOrigin, HttpError } from '@/lib/server/http';
import { requireSeller } from '@/lib/server/auth';
import { updateScanCoverage, startReconstruction, getOwnedScanSession } from '@/lib/server/reconstruction/pipeline';

/** Finalize a scan: persists coverage metrics and starts the reconstruction job. */
export const runtime = 'nodejs';
export const maxDuration = 60;

const schema = z.object({
  sessionId: z.string().uuid(),
  action: z.enum(['finalize', 'reconstruct']).default('finalize'),
  // Only used when action = 'finalize':
  coveragePct: z.number().int().min(0).max(100).optional(),
  scanQuality: z.enum(['unknown', 'low', 'medium', 'high']).optional(),
  coverageMap: z.record(z.string(), z.unknown()).optional(),
  warnings: z.array(z.unknown()).optional(),
  selectedFrames: z.number().int().min(0).max(240).optional(),
  frameCount: z.number().int().min(0).max(240).optional(),
});

export const POST = handle(async (req: Request) => {
  assertSameOrigin(req);
  const u = await requireSeller();
  const b = schema.parse(await req.json());

  if (b.action === 'finalize') {
    if (b.coveragePct == null || b.scanQuality == null) throw new HttpError(400, 'coveragePct and scanQuality are required when action = finalize');
    const row = await updateScanCoverage(u.sellerId, b.sessionId, {
      coveragePct: b.coveragePct, scanQuality: b.scanQuality,
      coverageMap: b.coverageMap || {}, warnings: b.warnings || [],
      selectedFrames: b.selectedFrames ?? 0, frameCount: b.frameCount ?? 0,
    });
    return json({ session: row });
  }

  // action === 'reconstruct'
  const session = await getOwnedScanSession(u.sellerId, b.sessionId);
  if (!session) throw new HttpError(404, 'Scan session not found');
  // If coverage wasn't finalized yet, fail politely.
  if (session.coverage_pct === 0) throw new HttpError(422, 'Finalize the scan coverage first.');
  const job = await startReconstruction(u.sellerId, b.sessionId);
  return json({ job }, 201);
});
