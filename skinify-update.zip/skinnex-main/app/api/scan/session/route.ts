import { z } from 'zod';
import { json, handle, assertSameOrigin } from '@/lib/server/http';
import { requireSeller } from '@/lib/server/auth';
import { createScanSession } from '@/lib/server/reconstruction/pipeline';

/** Create a new scan session. The client gets a sessionId back and starts capturing frames. */
export const runtime = 'nodejs';
export const maxDuration = 30;

const schema = z.object({
  categorySlug: z.string().max(60).nullable(),
  productName: z.string().trim().max(200).default(''),
  skinnerId: z.string().uuid().optional(),
  deviceInfo: z.record(z.string(), z.unknown()).optional(),
});

export const POST = handle(async (req: Request) => {
  assertSameOrigin(req);
  const u = await requireSeller();
  const b = schema.parse(await req.json());
  const row = await createScanSession(u.sellerId, { categorySlug: b.categorySlug, productName: b.productName, skinnerId: b.skinnerId, deviceInfo: b.deviceInfo });
  return json({ session: row }, 201);
});
