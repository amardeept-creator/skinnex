import { z } from 'zod';
import { json, handle, assertSameOrigin, HttpError } from '@/lib/server/http';
import { requireSeller } from '@/lib/server/auth';
import { getOwnedScanSession, listScanFrames, pollReconstruction } from '@/lib/server/reconstruction/pipeline';
import { sql } from '@/lib/server/db';

type Ctx = { params: Promise<{ id: string }> };

/** GET /api/scan/[id]
 *  - ?what=status    → just the session + latest job status (lightweight poll).
 *  - ?what=frames    → session + all stored frames.
 *  - ?what=job&jobId=...  → poll a specific reconstruction job.
 */
export const runtime = 'nodejs';
export const maxDuration = 30;

export const GET = handle(async (_req: Request, ctx: Ctx) => {
  const u = await requireSeller();
  const { id } = await ctx.params;
  const url = new URL(_req.url);
  const what = url.searchParams.get('what') || 'status';

  if (what === 'job') {
    const jobId = url.searchParams.get('jobId');
    if (!jobId) throw new HttpError(400, 'jobId required when what=job');
    return json({ job: await pollReconstruction(u.sellerId, jobId) });
  }

  if (what === 'frames') return json(await listScanFrames(u.sellerId, id));

  // status
  const session = await getOwnedScanSession(u.sellerId, id);
  if (!session) throw new HttpError(404, 'Scan session not found');
  const [job] = await sql`select id, status, progress, is_mock, error, asset_id, quality_report, provider, created_at, finished_at
    from reconstruction_jobs where session_id = ${id} order by created_at desc limit 1`;
  return json({ session, job: job || null });
});

/** DELETE /api/scan/[id] — cancels / discards a scan session (and its frames). */
export const DELETE = handle(async (req: Request, ctx: Ctx) => {
  assertSameOrigin(req);
  const u = await requireSeller();
  const { id } = await ctx.params;
  const session = await getOwnedScanSession(u.sellerId, id);
  if (!session) throw new HttpError(404, 'Scan session not found');
  await sql`delete from scan_sessions where id = ${id}`;
  return json({ ok: true });
});
