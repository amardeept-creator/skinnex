import { notFound } from 'next/navigation';
import Link from 'next/link';
import { pageSeller } from '@/lib/server/auth';
import { getOwnedSkinner } from '@/lib/server/skinners';
import { getEntitlement } from '@/lib/server/entitlements';
import { ModelViewer3D } from '@/components/scan/ModelViewer3D';
import { I } from '@/components/Icons';

/**
 * Standalone "View in your space" page for a Skinner's reconstructed 3D model.
 *
 * This is intentionally separate from /dashboard/skinners/[id]/preview (the
 * body-part-tracking AR engine). Surface-place Skinners and scanned products
 * use Google's <model-viewer> for the Google-like "View in your space" experience
 * — separate code path, no MediaPipe required.
 */
export default async function ViewSkinner({ params }: { params: Promise<{ id: string }> }) {
  const u = await pageSeller();
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/.test(id)) notFound();
  const s = await getOwnedSkinner(u.sellerId, id);
  if (!s) notFound();
  const e = await getEntitlement(u.sellerId);

  // No model attached → bounce the user back to the wizard.
  if (!s.model_url) {
    return (
      <div className="card card-pad" style={{ maxWidth: 560, margin: '40px auto' }}>
        <h1 style={{ fontSize: 28 }}>No 3D model attached yet</h1>
        <p className="muted" style={{ marginTop: 8 }}>This Skinner doesn&rsquo;t have a 3D model yet. Scan a physical product or attach an existing GLB to enable &ldquo;View in your space&rdquo;.</p>
        <Link href={`/dashboard/skinners/${s.id}`} className="btn btn-primary" style={{ marginTop: 16 }}>Edit Skinner</Link>
      </div>
    );
  }

  const meta = (s.asset_meta || {}) as { triangles?: number; materials?: string[]; textures?: number; bbox?: { size: number[] }; warnings?: string[]; scan?: { mock?: boolean; coverage?: number; scanQuality?: string } };
  const isScan = !!meta.scan;
  const fitSize = s.config?.size?.fitSize ?? 0.3;

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="dash-head">
        <div>
          <div className="eyebrow">View in your space</div>
          <h1 style={{ marginTop: 6 }}>{s.p_name}</h1>
          <p className="small muted" style={{ marginTop: 4 }}>{s.brand_name} · {isScan ? `Scanned · ${meta.scan?.coverage ?? 0}% coverage${meta.scan?.mock ? ' · prototype' : ''}` : '3D model'}</p>
        </div>
        <span className="spacer" />
        <Link href={`/dashboard/skinners/${s.id}`} className="btn btn-ghost"><I.back size={16} />Back to edit</Link>
      </div>

      <div className="card" style={{ overflow: 'hidden', padding: 0 }}>
        <div style={{ position: 'relative', aspectRatio: '16 / 11', minHeight: 460, maxHeight: '70vh' }}>
          <ModelViewer3D
            modelUrl={s.model_url}
            productName={s.p_name}
            scaleMeters={fitSize}
            autoRotate
            info={{
              triangles: meta.triangles,
              textures: meta.textures,
              bytes: s.asset_bytes,
              warnings: meta.warnings,
              isMock: !!meta.scan?.mock,
            }}
          />
        </div>
      </div>

      <div className="card card-pad">
        <b>About this experience</b>
        <p className="small muted" style={{ marginTop: 6 }}>
          This page uses Google&rsquo;s <code>&lt;model-viewer&gt;</code> web component. On Android devices with ARCore, the &ldquo;View in your space&rdquo; button opens Scene Viewer; on supported iPhones / iPads it opens Quick Look; on desktop you get an interactive 3D viewer with rotate / zoom / pan / fullscreen controls. The button is hidden automatically when AR isn&rsquo;t supported.
          {!e.limits?.remove_branding && ' The SKINIFY badge is shown for trial / starter plans; remove it by upgrading.'}
        </p>
        {isScan && meta.scan?.mock && (
          <p className="small" style={{ marginTop: 8, color: 'var(--warn)' }}>⚠ Prototype: this model was produced by the mock reconstruction provider. Connect a real provider via <code>RECONSTRUCTION_PROVIDER</code> to produce scan-based models.</p>
        )}
        <div className="row" style={{ flexWrap: 'wrap', marginTop: 12 }}>
          <Link href={`/dashboard/skinners/${s.id}/preview`} className="btn btn-ghost"><I.camera size={16} /> Live AR preview (body tracker)</Link>
          {s.link_slug && <a className="btn btn-iris" href={`/s/${s.link_slug}`} target="_blank" rel="noopener noreferrer"><I.link size={16} /> Open public link</a>}
        </div>
      </div>
    </div>
  );
}
