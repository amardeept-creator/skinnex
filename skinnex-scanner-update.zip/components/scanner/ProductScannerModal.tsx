'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  ProductCategory,
  ARBodyTarget,
  ScannerState,
  ScanFacet,
  CapturedFrame,
} from '@/lib/scanner/types';
import {
  CATEGORY_PROFILES,
  evaluateFrameQuality,
  determineActiveFacet,
  computeCoverageAndGuidance,
} from '@/lib/scanner/scannerEngine';
import { removeProductBackground } from '@/lib/scanner/segmentation';
import { generateArReadyGlb } from '@/lib/scanner/meshGenerator';

interface ProductScannerModalProps {
  isOpen: boolean;
  category: ProductCategory;
  target: ARBodyTarget;
  onClose: () => void;
  onComplete: (data: {
    glbBlob: Blob;
    previewUrl: string;
    coverImageUrl: string;
    metrics: { geometry: number; texture: number; coverage: number };
  }) => void;
}

export default function ProductScannerModal({
  isOpen,
  category,
  target,
  onClose,
  onComplete,
}: ProductScannerModalProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [hasStarted, setHasStarted] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastQuality, setLastQuality] = useState<'HIGH' | 'MEDIUM' | 'LOW'>('HIGH');

  const profile = CATEGORY_PROFILES[category] || CATEGORY_PROFILES.general;

  const [state, setState] = useState<ScannerState>({
    isScanning: false,
    totalCoverage: 0,
    qualityScore: 85,
    capturedFrames: [],
    facets: profile.facets.map((f) => ({
      id: f.id,
      label: f.label,
      coverage: 0,
      status: 'not_captured',
      required: f.required,
    })),
    activeInstruction: 'Take the first photo to establish product base',
    activeDirection: 'steady',
    progressiveStage: 25,
    stageLabel: 'Waiting for first capture',
    canCreateAnyway: false,
    isModelReady: false,
    generatedGlbBlob: null,
    generatedPreviewUrl: null,
    segmentationSuccess: true,
  });

  const startCamera = async () => {
    setCameraError(null);
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      setCameraError('Camera access denied or unavailable. You can still upload photos manually.');
    }
  };

  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
        setStream(null);
      }
      setHasStarted(false);
    }
    return () => {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [isOpen]);

  const captureFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const quality = evaluateFrameQuality(ctx, canvas.width, canvas.height);
    setLastQuality(quality.level);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.88);
    const frameIndex = state.capturedFrames.length;

    const simulatedAzimuth = (frameIndex * 75) % 360;
    const simulatedPitch = frameIndex === 0 ? 0 : frameIndex % 3 === 0 ? -40 : 10;
    const facetId = determineActiveFacet(simulatedAzimuth, simulatedPitch, category);

    const newFrame: CapturedFrame = {
      id: `frame_${Date.now()}_${frameIndex}`,
      timestamp: Date.now(),
      dataUrl,
      thumbnailUrl: dataUrl,
      facet: facetId,
      qualityScore: quality.score,
      qualityLevel: quality.level,
      angleAzimuth: simulatedAzimuth,
      angleElevation: simulatedPitch,
    };

    const newFrames = [...state.capturedFrames, newFrame];
    const {
      totalCoverage,
      updatedFacets,
      guidanceText,
      direction,
      progressiveStage,
      stageLabel,
      canCreateAnyway,
    } = computeCoverageAndGuidance(state.facets, newFrames);

    setState((prev) => ({
      ...prev,
      capturedFrames: newFrames,
      facets: updatedFacets,
      totalCoverage,
      activeInstruction: guidanceText,
      activeDirection: direction,
      progressiveStage,
      stageLabel,
      canCreateAnyway,
      isScanning: true,
    }));

    if (!hasStarted) setHasStarted(true);
  }, [hasStarted, state.capturedFrames, state.facets, category]);

  const handleFinalizeModel = async () => {
    if (state.capturedFrames.length === 0) return;
    setIsProcessing(true);

    try {
      const segResult = await removeProductBackground(state.capturedFrames[0].dataUrl);

      const { blob, previewUrl, qualityMetrics } = await generateArReadyGlb(
        state.capturedFrames,
        category,
        target,
        segResult.resultDataUrl
      );

      setIsProcessing(false);
      onComplete({
        glbBlob: blob,
        previewUrl,
        coverImageUrl: segResult.resultDataUrl,
        metrics: qualityMetrics,
      });
      onClose();
    } catch (err) {
      setIsProcessing(false);
      alert('Could not complete 3D generation. Defaulting to high-quality planar AR representation.');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 text-white p-3 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-zinc-950 border border-zinc-800 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div>
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              SKINIFY Product Scanner
            </h2>
            <p className="text-xs text-zinc-400 capitalize">
              Target: {category} · {target.replace('_', ' ')}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-white p-1 rounded-full hover:bg-zinc-800 transition"
          >
            ✕
          </button>
        </div>

        <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden bg-black border border-zinc-800 flex items-center justify-center">
          {cameraError ? (
            <div className="p-4 text-center text-sm text-red-400">{cameraError}</div>
          ) : (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
          )}
          <canvas ref={canvasRef} className="hidden" />

          <div className="absolute inset-8 border border-white/20 rounded-2xl pointer-events-none flex flex-col justify-between p-3">
            <div className="flex justify-between">
              <span className="w-4 h-4 border-t-2 border-l-2 border-indigo-400" />
              <span className="w-4 h-4 border-t-2 border-r-2 border-indigo-400" />
            </div>
            <div className="flex justify-between">
              <span className="w-4 h-4 border-b-2 border-l-2 border-indigo-400" />
              <span className="w-4 h-4 border-b-2 border-r-2 border-indigo-400" />
            </div>
          </div>

          {hasStarted && (
            <div className="absolute top-3 left-3 right-3 bg-black/70 backdrop-blur-md rounded-xl p-2.5 border border-white/10 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-indigo-600/30 border border-indigo-500 flex items-center justify-center font-bold text-indigo-300">
                {state.activeDirection === 'left' && '←'}
                {state.activeDirection === 'right' && '→'}
                {state.activeDirection === 'downward' && '↓'}
                {state.activeDirection === 'higher' && '↑'}
                {state.activeDirection === 'back' && '↺'}
                {state.activeDirection === 'steady' && '✓'}
              </div>
              <div className="text-xs font-medium text-zinc-100 flex-1">
                {state.activeInstruction}
              </div>
              <span
                className={`text-[10px] px-2 py-0.5 rounded font-mono uppercase ${
                  lastQuality === 'HIGH'
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    : lastQuality === 'MEDIUM'
                    ? 'bg-amber-950 text-amber-400 border border-amber-800'
                    : 'bg-zinc-800 text-zinc-400'
                }`}
              >
                {lastQuality}
              </span>
            </div>
          )}
        </div>

        <div className="space-y-2 bg-zinc-900/60 p-3.5 rounded-2xl border border-zinc-800/80">
          <div className="flex justify-between text-xs font-semibold text-zinc-200">
            <span>SCAN COVERAGE</span>
            <span className="text-indigo-400 font-mono text-sm">{state.totalCoverage}%</span>
          </div>

          <div className="w-full bg-zinc-800 rounded-full h-2.5 overflow-hidden flex">
            <div
              className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full transition-all duration-300 rounded-full"
              style={{ width: `${state.totalCoverage}%` }}
            />
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 pt-1.5">
            {state.facets.map((facet) => (
              <div
                key={facet.id}
                className="flex flex-col items-center bg-zinc-950 border border-zinc-800/60 rounded-lg p-1.5 text-center"
              >
                <div
                  className={`w-2.5 h-2.5 rounded-full mb-1 ${
                    facet.status === 'captured'
                      ? 'bg-emerald-400 shadow-sm shadow-emerald-500/50'
                      : facet.status === 'partial'
                      ? 'bg-amber-400'
                      : facet.status === 'reconstructed'
                      ? 'bg-indigo-400'
                      : 'bg-zinc-700'
                  }`}
                />
                <span className="text-[10px] text-zinc-300 truncate w-full">{facet.label}</span>
                <span className="text-[9px] font-mono text-zinc-500">{facet.coverage}%</span>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center text-[11px] text-zinc-400 pt-1 border-t border-zinc-800/50">
            <span>Reconstruction Stage:</span>
            <span className="text-zinc-200 font-medium">{state.stageLabel}</span>
          </div>
        </div>

        {state.capturedFrames.length > 0 && (
          <div className="flex gap-2 overflow-x-auto py-1 scrollbar-none">
            {state.capturedFrames.map((frame, i) => (
              <div
                key={frame.id}
                className="relative flex-shrink-0 w-12 h-12 rounded-lg overflow-hidden border border-zinc-700 bg-zinc-900"
              >
                <img src={frame.dataUrl} alt="scan" className="w-full h-full object-cover" />
                <span className="absolute bottom-0 right-0 bg-black/70 text-[8px] font-mono px-1 text-white">
                  #{i + 1}
                </span>
              </div>
            ))}
          </div>
        )}

        <div className="flex flex-col gap-2 pt-1">
          {!hasStarted ? (
            <button
              onClick={captureFrame}
              className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 active:scale-[0.99] text-white font-semibold rounded-2xl shadow-lg shadow-indigo-600/25 transition text-sm flex items-center justify-center gap-2"
            >
              📸 TAKE FIRST PHOTO
            </button>
          ) : (
            <div className="flex gap-2.5">
              <button
                onClick={captureFrame}
                className="flex-1 py-3 bg-zinc-800 hover:bg-zinc-700 active:scale-[0.99] text-white font-medium rounded-xl text-sm transition"
              >
                📸 Capture Angle ({state.capturedFrames.length})
              </button>

              {state.canCreateAnyway && (
                <button
                  onClick={handleFinalizeModel}
                  disabled={isProcessing}
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.99] text-white font-semibold rounded-xl text-sm transition flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-600/20"
                >
                  {isProcessing ? (
                    <span className="animate-spin text-base">⏳</span>
                  ) : (
                    '✨ Generate Model'
                  )}
                </button>
              )}
            </div>
          )}

          {state.totalCoverage >= 80 && (
            <p className="text-[11px] text-center text-emerald-400">
              ✓ Sufficient coverage captured for high-fidelity AR placement.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
