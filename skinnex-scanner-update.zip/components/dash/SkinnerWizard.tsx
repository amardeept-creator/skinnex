'use client';

import React, { useState } from 'react';
import ProductScannerModal from '@/components/scanner/ProductScannerModal';
import { ProductCategory, ARBodyTarget } from '@/lib/scanner/types';
import { CATEGORY_PROFILES } from '@/lib/scanner/scannerEngine';

interface SkinnerWizardProps {
  initialBrandName?: string;
  onSave?: (skinnerData: any) => Promise<void>;
}

export default function SkinnerWizard({ initialBrandName = 'Skinify Brand', onSave }: SkinnerWizardProps) {
  const [currentStep, setCurrentStep] = useState<number>(1);

  const [productName, setProductName] = useState('');
  const [brand, setBrand] = useState(initialBrandName);
  const [category, setCategory] = useState<ProductCategory>('rings');
  const [customCategory, setCustomCategory] = useState('');
  const [subcategory, setSubcategory] = useState('');
  const [price, setPrice] = useState('$199');
  const [description, setDescription] = useState('');
  const [sku, setSku] = useState('');

  const [target, setTarget] = useState<ARBodyTarget>('finger');

  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannedModelBlob, setScannedModelBlob] = useState<Blob | null>(null);
  const [scannedPreviewUrl, setScannedPreviewUrl] = useState<string | null>(null);
  const [productCoverImage, setProductCoverImage] = useState<string | null>(null);
  const [qualityMetrics, setQualityMetrics] = useState({ geometry: 85, texture: 90, coverage: 82 });

  const [scale, setScale] = useState(1.0);
  const [rotationX, setRotationX] = useState(0);
  const [rotationY, setRotationY] = useState(0);

  const [primaryColor, setPrimaryColor] = useState('#4F46E5');
  const [ctaLabel, setCtaLabel] = useState('Shop Now');
  const [ctaUrl, setCtaUrl] = useState('https://yourbrand.com/product');

  const [isPublished, setIsPublished] = useState(false);
  const [publishedSlug, setPublishedSlug] = useState('');

  const handleCategoryChange = (newCat: ProductCategory) => {
    setCategory(newCat);
    if (CATEGORY_PROFILES[newCat]) {
      setTarget(CATEGORY_PROFILES[newCat].defaultTarget);
    }
  };

  const handleScannerComplete = (data: {
    glbBlob: Blob;
    previewUrl: string;
    coverImageUrl: string;
    metrics: { geometry: number; texture: number; coverage: number };
  }) => {
    setScannedModelBlob(data.glbBlob);
    setScannedPreviewUrl(data.previewUrl);
    setProductCoverImage(data.coverImageUrl);
    setQualityMetrics(data.metrics);
    setCurrentStep(4);
  };

  const handlePublish = async () => {
    const slug = productName.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'custom-product';
    setPublishedSlug(slug);
    setIsPublished(true);
    if (onSave) {
      await onSave({
        name: productName,
        brand,
        category,
        target,
        price,
        description,
        slug,
        scale,
        primaryColor,
        ctaLabel,
        ctaUrl,
        glbBlob: scannedModelBlob,
      });
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-8 bg-zinc-950 text-white rounded-3xl border border-zinc-800 shadow-2xl">
      <div className="flex justify-between items-center mb-8 border-b border-zinc-800 pb-4">
        {[
          { step: 1, label: 'Product Info' },
          { step: 2, label: 'AR Target' },
          { step: 3, label: 'Scan 3D' },
          { step: 4, label: 'Calibrate' },
          { step: 5, label: 'Branding & CTA' },
          { step: 6, label: 'Publish' },
        ].map((item) => (
          <div
            key={item.step}
            onClick={() => item.step <= currentStep && setCurrentStep(item.step)}
            className={`flex items-center gap-2 cursor-pointer text-xs font-semibold ${
              currentStep === item.step
                ? 'text-indigo-400'
                : currentStep > item.step
                ? 'text-zinc-400'
                : 'text-zinc-600'
            }`}
          >
            <span
              className={`w-6 h-6 rounded-full flex items-center justify-center border text-[11px] ${
                currentStep === item.step
                  ? 'border-indigo-500 bg-indigo-950 text-indigo-300'
                  : currentStep > item.step
                  ? 'border-zinc-700 bg-zinc-900 text-zinc-300'
                  : 'border-zinc-800 text-zinc-600'
              }`}
            >
              {item.step}
            </span>
            <span className="hidden sm:inline">{item.label}</span>
          </div>
        ))}
      </div>

      {currentStep === 1 && (
        <div className="space-y-5">
          <h2 className="text-xl font-bold text-zinc-100">Step 1 — Product Information</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-zinc-400 block mb-1">Product Name *</label>
              <input
                type="text"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="e.g. Royal Diamond Solitaire Ring"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-indigo-500 outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-zinc-400 block mb-1">Brand</label>
              <input
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-indigo-500 outline-none"
              />
            </div>

            <div>
              <label className="text-xs text-zinc-400 block mb-1">Category *</label>
              <select
                value={category}
                onChange={(e) => handleCategoryChange(e.target.value as ProductCategory)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-indigo-500 outline-none capitalize"
              >
                <option value="rings">💍 Rings</option>
                <option value="watches">⌚ Watches</option>
                <option value="bracelets">💎 Bracelets</option>
                <option value="bangles">🟡 Bangles</option>
                <option value="earrings">👂 Earrings</option>
                <option value="necklaces">📿 Necklaces</option>
                <option value="glasses">👓 Glasses / Eyewear</option>
                <option value="shoes">👟 Shoes</option>
                <option value="bags">👜 Bags & Handbags</option>
                <option value="clothing">👕 Clothing</option>
                <option value="accessories">🕶️ Accessories</option>
                <option value="beauty">💄 Beauty & Swatches</option>
                <option value="furniture">🪑 Furniture</option>
                <option value="general">📦 General Product</option>
                <option value="custom">✨ Custom Category</option>
              </select>
            </div>

            {category === 'custom' ? (
              <div>
                <label className="text-xs text-zinc-400 block mb-1">Custom Category Name</label>
                <input
                  type="text"
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  placeholder="e.g. Vintage Artifact"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-indigo-500 outline-none"
                />
              </div>
            ) : (
              <div>
                <label className="text-xs text-zinc-400 block mb-1">Subcategory</label>
                <input
                  type="text"
                  value={subcategory}
                  onChange={(e) => setSubcategory(e.target.value)}
                  placeholder="e.g. Engagement Rings / Platinum"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-indigo-500 outline-none"
                />
              </div>
            )}

            <div>
              <label className="text-xs text-zinc-400 block mb-1">Price</label>
              <input
                type="text"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="$299.00"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-indigo-500 outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-zinc-400 block mb-1">SKU / Code</label>
              <input
                type="text"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                placeholder="SKN-9021"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:border-indigo-500 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-zinc-400 block mb-1">Product Description</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe materials, sizing, and details..."
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white focus:border-indigo-500 outline-none"
            />
          </div>

          <div className="flex justify-end pt-4">
            <button
              onClick={() => setCurrentStep(2)}
              disabled={!productName.trim()}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium rounded-xl text-sm transition"
            >
              Next: Select AR Target →
            </button>
          </div>
        </div>
      )}

      {currentStep === 2 && (
        <div className="space-y-5">
          <h2 className="text-xl font-bold text-zinc-100">Step 2 — Select AR Target Placement</h2>
          <p className="text-xs text-zinc-400">
            SKINIFY automatically suggested <span className="text-indigo-400 font-semibold">{target}</span> for {category}.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { id: 'finger', label: '💍 Finger', desc: 'Hand & finger tracking' },
              { id: 'wrist', label: '⌚ Wrist', desc: 'Watches & bracelets' },
              { id: 'ear', label: '👂 Ear', desc: 'Earrings & cuffs' },
              { id: 'neck_chest', label: '📿 Neck / Chest', desc: 'Necklaces & chains' },
              { id: 'face', label: '👓 Face', desc: 'Glasses, cosmetics' },
              { id: 'feet', label: '👟 Feet', desc: 'Shoes & footwear' },
              { id: 'hand_shoulder', label: '👜 Hand / Shoulder', desc: 'Bags & clutches' },
              { id: 'body', label: '👕 Body', desc: 'Jackets & apparel' },
              { id: 'room_environment', label: '🪑 Room Placement', desc: 'Surface plane detection' },
              { id: 'object_placement', label: '📦 Free Placement', desc: 'Any surface' },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTarget(t.id as ARBodyTarget)}
                className={`p-3.5 rounded-2xl border text-left transition flex flex-col justify-between ${
                  target === t.id
                    ? 'border-indigo-500 bg-indigo-950/40 text-white'
                    : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <div className="text-sm font-semibold text-zinc-100 mb-1">{t.label}</div>
                <div className="text-[11px] text-zinc-500">{t.desc}</div>
              </button>
            ))}
          </div>

          <div className="flex justify-between pt-4">
            <button
              onClick={() => setCurrentStep(1)}
              className="px-5 py-2.5 border border-zinc-800 text-zinc-300 rounded-xl text-sm hover:bg-zinc-900"
            >
              ← Back
            </button>
            <button
              onClick={() => setCurrentStep(3)}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-xl text-sm transition"
            >
              Next: Product Digitization →
            </button>
          </div>
        </div>
      )}

      {currentStep === 3 && (
        <div className="space-y-6 text-center py-4">
          <div className="w-16 h-16 mx-auto rounded-3xl bg-indigo-600/20 border border-indigo-500 flex items-center justify-center text-3xl">
            📷
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Let's scan your {productName || 'product'}</h2>
            <p className="text-xs text-zinc-400 max-w-md mx-auto">
              Place your product on a well-lit surface. Keep it clearly visible and move your phone slowly around it. SKINIFY progressively reconstructs the 3D model on your device.
            </p>
          </div>

          <div className="max-w-md mx-auto p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 text-left text-xs space-y-2 text-zinc-300">
            <div className="font-semibold text-zinc-100 mb-1">Scanning Advice:</div>
            <div>• Move around all angles (Front, Sides, Top, Back).</div>
            <div>• Natural, diffused light produces the best texture colors.</div>
            <div>• Perfect scanning is NOT required — SKINIFY intelligently fills unseen geometry.</div>
          </div>

          <div className="flex flex-col sm:flex-row justify-center gap-3 pt-2">
            <button
              onClick={() => setIsScannerOpen(true)}
              className="px-8 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-2xl shadow-xl shadow-indigo-600/30 text-sm transition flex items-center justify-center gap-2"
            >
              📸 Launch Guided Scanner
            </button>
          </div>

          {scannedPreviewUrl && (
            <div className="mt-4 p-4 rounded-2xl border border-emerald-800 bg-emerald-950/20 text-emerald-300 text-xs">
              ✓ 3D Model created successfully! You can proceed to calibration.
            </div>
          )}

          <div className="flex justify-between pt-6 border-t border-zinc-900">
            <button
              onClick={() => setCurrentStep(2)}
              className="px-5 py-2 border border-zinc-800 text-zinc-400 rounded-xl text-sm"
            >
              ← Back
            </button>
            {scannedPreviewUrl && (
              <button
                onClick={() => setCurrentStep(4)}
                className="px-6 py-2 bg-emerald-600 text-white font-medium rounded-xl text-sm"
              >
                Proceed to Calibration →
              </button>
            )}
          </div>
        </div>
      )}

      {currentStep === 4 && (
        <div className="space-y-6">
          <h2 className="text-xl font-bold text-zinc-100">Step 4 — Calibration & AR Readiness</h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800">
            <div>
              <div className="text-[11px] text-zinc-400">Geometry</div>
              <div className="text-lg font-bold text-emerald-400 font-mono">{qualityMetrics.geometry}%</div>
            </div>
            <div>
              <div className="text-[11px] text-zinc-400">Texture Quality</div>
              <div className="text-lg font-bold text-emerald-400 font-mono">{qualityMetrics.texture}%</div>
            </div>
            <div>
              <div className="text-[11px] text-zinc-400">Scan Coverage</div>
              <div className="text-lg font-bold text-indigo-400 font-mono">{qualityMetrics.coverage}%</div>
            </div>
            <div>
              <div className="text-[11px] text-zinc-400">AR Status</div>
              <div className="text-sm font-semibold text-emerald-400 mt-1 flex items-center gap-1">
                ✓ Ready for AR
              </div>
            </div>
          </div>

          <div className="aspect-video w-full rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center relative overflow-hidden">
            {productCoverImage ? (
              <img src={productCoverImage} alt="Cover" className="h-full object-contain" />
            ) : (
              <div className="text-zinc-500 text-sm">3D Model Ready for Placement</div>
            )}
            <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur px-3 py-1 rounded-full text-xs text-zinc-300 border border-zinc-700">
              Anchor: {target}
            </div>
          </div>

          <div className="space-y-3 bg-zinc-900/40 p-4 rounded-2xl border border-zinc-800/80">
            <h3 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
              Fine-tune AR Anchor & Scale
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-xs text-zinc-400 block mb-1">Scale ({scale.toFixed(2)}x)</label>
                <input
                  type="range"
                  min="0.5"
                  max="2.0"
                  step="0.05"
                  value={scale}
                  onChange={(e) => setScale(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500"
                />
              </div>
              <div>
                <label className="text-xs text-zinc-400 block mb-1">Rotation X ({rotationX}°)</label>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  value={rotationX}
                  onChange={(e) => setRotationX(parseInt(e.target.value))}
                  className="w-full accent-indigo-500"
                />
              </div>
              <div>
                <label className="text-xs text-zinc-400 block mb-1">Rotation Y ({rotationY}°)</label>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  value={rotationY}
                  onChange={(e) => setRotationY(parseInt(e.target.value))}
                  className="w-full accent-indigo-500"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-between pt-4">
            <button
              onClick={() => setCurrentStep(3)}
              className="px-5 py-2.5 border border-zinc-800 text-zinc-400 rounded-xl text-sm"
            >
              ← Rescan Model
            </button>
            <button
              onClick={() => setCurrentStep(5)}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-xl text-sm"
            >
              Next: Branding & CTA →
            </button>
          </div>
        </div>
      )}

      {currentStep === 5 && (
        <div className="space-y-5">
          <h2 className="text-xl font-bold text-zinc-100">Step 5 — Branding & Call-to-Action</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-zinc-400 block mb-1">Brand Accent Color</label>
              <div className="flex gap-2 items-center">
                <input
                  type="color"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                />
                <input
                  type="text"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white font-mono"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-zinc-400 block mb-1">CTA Button Text</label>
              <select
                value={ctaLabel}
                onChange={(e) => setCtaLabel(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm text-white outline-none"
              >
                <option value="Shop Now">Shop Now</option>
                <option value="Buy Now">Buy Now</option>
                <option value="Add to Cart">Add to Cart</option>
                <option value="Contact Brand">Contact Brand</option>
                <option value="WhatsApp">WhatsApp</option>
                <option value="View Product">View Product</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="text-xs text-zinc-400 block mb-1">CTA Destination Link</label>
              <input
                type="url"
                value={ctaUrl}
                onChange={(e) => setCtaUrl(e.target.value)}
                placeholder="https://yourstore.com/products/ring-123"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm text-white outline-none"
              />
            </div>
          </div>

          <div className="flex justify-between pt-4">
            <button
              onClick={() => setCurrentStep(4)}
              className="px-5 py-2.5 border border-zinc-800 text-zinc-400 rounded-xl text-sm"
            >
              ← Back
            </button>
            <button
              onClick={handlePublish}
              className="px-8 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl text-sm shadow-lg shadow-emerald-600/20"
            >
              Publish AR Skinner 🚀
            </button>
          </div>
        </div>
      )}

      {(currentStep === 6 || isPublished) && (
        <div className="text-center py-8 space-y-5">
          <div className="w-16 h-16 mx-auto rounded-full bg-emerald-600/20 border border-emerald-500 text-emerald-400 flex items-center justify-center text-3xl">
            ✓
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Your Skinner is Live!</h2>
            <p className="text-xs text-zinc-400">
              Customers can now try <span className="text-white font-medium">{productName}</span> in live AR.
            </p>
          </div>

          <div className="max-w-md mx-auto p-4 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-between">
            <div className="text-xs text-zinc-300 font-mono truncate mr-2">
              https://skinify-ar.vercel.app/s/{publishedSlug}
            </div>
            <button
              onClick={() => {
                navigator.clipboard.writeText(`https://skinify-ar.vercel.app/s/${publishedSlug}`);
                alert('Copied to clipboard!');
              }}
              className="px-3 py-1.5 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-500 transition"
            >
              Copy
            </button>
          </div>

          <div className="flex justify-center gap-3 pt-4">
            <a
              href={`/s/${publishedSlug}?src=share`}
              target="_blank"
              rel="noreferrer"
              className="px-6 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white text-sm font-medium rounded-xl"
            >
              Test Mobile AR 📱
            </a>
            <button
              onClick={() => {
                setIsPublished(false);
                setCurrentStep(1);
                setProductName('');
              }}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-xl"
            >
              Create Another Skinner
            </button>
          </div>
        </div>
      )}

      <ProductScannerModal
        isOpen={isScannerOpen}
        category={category}
        target={target}
        onClose={() => setIsScannerOpen(false)}
        onComplete={handleScannerComplete}
      />
    </div>
  );
}
