export type ProductCategory =
  | 'rings'
  | 'watches'
  | 'bracelets'
  | 'bangles'
  | 'earrings'
  | 'necklaces'
  | 'glasses'
  | 'shoes'
  | 'bags'
  | 'clothing'
  | 'accessories'
  | 'beauty'
  | 'furniture'
  | 'general'
  | 'custom';

export type ARBodyTarget =
  | 'finger'
  | 'wrist'
  | 'ear'
  | 'neck_chest'
  | 'face'
  | 'feet'
  | 'hand_shoulder'
  | 'body'
  | 'room_environment'
  | 'object_placement';

export type ScanFacetId =
  | 'front'
  | 'left'
  | 'right'
  | 'back'
  | 'top'
  | 'bottom'
  | 'detail';

export type CoverageStatus = 'not_captured' | 'partial' | 'captured' | 'reconstructed';

export interface ScanFacet {
  id: ScanFacetId;
  label: string;
  coverage: number; // 0 to 100
  status: CoverageStatus;
  required: boolean;
}

export interface CapturedFrame {
  id: string;
  timestamp: number;
  dataUrl: string;
  thumbnailUrl: string;
  facet: ScanFacetId;
  qualityScore: number; // 0 to 100
  qualityLevel: 'HIGH' | 'MEDIUM' | 'LOW';
  angleAzimuth: number; // -180 to 180 deg
  angleElevation: number; // -90 to 90 deg
}

export interface ScannerState {
  isScanning: boolean;
  totalCoverage: number; // 0 to 100
  qualityScore: number; // 0 to 100
  capturedFrames: CapturedFrame[];
  facets: ScanFacet[];
  activeInstruction: string;
  activeDirection: 'left' | 'right' | 'higher' | 'lower' | 'downward' | 'back' | 'closer' | 'away' | 'steady';
  progressiveStage: 25 | 50 | 75 | 90 | 100;
  stageLabel: string;
  canCreateAnyway: boolean;
  isModelReady: boolean;
  generatedGlbBlob: Blob | null;
  generatedPreviewUrl: string | null;
  segmentationSuccess: boolean;
}

export interface CategoryScanProfile {
  facets: { id: ScanFacetId; label: string; required: boolean }[];
  defaultTarget: ARBodyTarget;
  recommendedDistanceCm: number;
  scaleEstimateMeters: number;
  guidanceNotes: string[];
}
