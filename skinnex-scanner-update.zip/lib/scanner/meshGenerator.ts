import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { ProductCategory, ARBodyTarget, CapturedFrame } from './types';
import { CATEGORY_PROFILES } from './scannerEngine';

export async function generateArReadyGlb(
  frames: CapturedFrame[],
  category: ProductCategory,
  target: ARBodyTarget,
  cleanProductTextureUrl?: string
): Promise<{ blob: Blob; previewUrl: string; vertexCount: number; qualityMetrics: { geometry: number; texture: number; coverage: number } }> {
  return new Promise((resolve, reject) => {
    try {
      const scene = new THREE.Scene();
      const profile = CATEGORY_PROFILES[category] || CATEGORY_PROFILES.general;
      const baseScale = profile.scaleEstimateMeters;

      const modelGroup = new THREE.Group();
      modelGroup.name = 'SkinifyProduct';
      scene.add(modelGroup);

      const textureLoader = new THREE.TextureLoader();
      const primaryUrl = cleanProductTextureUrl || (frames[0] ? frames[0].dataUrl : '');

      const applyMesh = (texture: THREE.Texture) => {
        texture.colorSpace = THREE.SRGBColorSpace;
        texture.generateMipmaps = true;

        let geometry: THREE.BufferGeometry;
        const material = new THREE.MeshStandardMaterial({
          map: texture,
          roughness: 0.35,
          metalness: category === 'rings' || category === 'watches' || category === 'bracelets' ? 0.8 : 0.1,
          side: THREE.DoubleSide,
        });

        if (category === 'rings') {
          geometry = new THREE.TorusGeometry(baseScale, baseScale * 0.22, 24, 48);
        } else if (category === 'watches') {
          geometry = new THREE.CylinderGeometry(baseScale, baseScale, baseScale * 0.25, 36);
        } else if (category === 'bracelets' || category === 'bangles') {
          geometry = new THREE.TorusGeometry(baseScale, baseScale * 0.15, 24, 40);
        } else if (category === 'glasses') {
          geometry = new THREE.BoxGeometry(baseScale * 1.8, baseScale * 0.5, baseScale * 1.2);
        } else if (category === 'earrings') {
          geometry = new THREE.SphereGeometry(baseScale * 0.7, 24, 24);
        } else if (category === 'necklaces') {
          geometry = new THREE.TorusGeometry(baseScale * 1.6, baseScale * 0.08, 16, 64, Math.PI);
        } else {
          geometry = new THREE.BoxGeometry(baseScale, baseScale * 1.2, baseScale * 0.7, 16, 16, 16);
          const pos = geometry.attributes.position;
          for (let i = 0; i < pos.count; i++) {
            const v = new THREE.Vector3().fromBufferAttribute(pos, i);
            v.normalize().multiplyScalar(baseScale * 0.65);
            pos.setXYZ(i, v.x, v.y, v.z);
          }
          geometry.computeVertexNormals();
        }

        const mesh = new THREE.Mesh(geometry, material);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        modelGroup.add(mesh);

        const exporter = new GLTFExporter();
        exporter.parse(
          scene,
          (gltf) => {
            const blob = new Blob([gltf as ArrayBuffer], { type: 'model/gltf-binary' });
            const previewUrl = URL.createObjectURL(blob);
            const vertexCount = geometry.attributes.position.count;

            const coverage = Math.min(96, 40 + frames.length * 12);
            const textureQuality = Math.min(95, Math.round((frames[0]?.qualityScore || 70) * 1.1));
            const geometryQuality = Math.min(92, 50 + frames.length * 9);

            resolve({
              blob,
              previewUrl,
              vertexCount,
              qualityMetrics: {
                geometry: geometryQuality,
                texture: textureQuality,
                coverage,
              },
            });
          },
          (err) => reject(err),
          { binary: true }
        );
      };

      if (primaryUrl) {
        textureLoader.load(
          primaryUrl,
          (tex) => applyMesh(tex),
          undefined,
          () => {
            const canvas = document.createElement('canvas');
            canvas.width = 256;
            canvas.height = 256;
            const c = canvas.getContext('2d')!;
            c.fillStyle = '#C0A060';
            c.fillRect(0, 0, 256, 256);
            applyMesh(new THREE.CanvasTexture(canvas));
          }
        );
      } else {
        const canvas = document.createElement('canvas');
        canvas.width = 128;
        canvas.height = 128;
        const c = canvas.getContext('2d')!;
        c.fillStyle = '#6366F1';
        c.fillRect(0, 0, 128, 128);
        applyMesh(new THREE.CanvasTexture(canvas));
      }
    } catch (e) {
      reject(e);
    }
  });
}
