export async function removeProductBackground(
  imageSrc: string
): Promise<{ success: boolean; resultDataUrl: string; confidence: number }> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        const w = Math.min(img.naturalWidth, 600);
        const h = Math.round((w / img.naturalWidth) * img.naturalHeight);
        canvas.width = w;
        canvas.height = h;

        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) {
          resolve({ success: false, resultDataUrl: imageSrc, confidence: 50 });
          return;
        }

        ctx.drawImage(img, 0, 0, w, h);
        const imgData = ctx.getImageData(0, 0, w, h);
        const d = imgData.data;

        let bgR = 0, bgG = 0, bgB = 0, bgCount = 0;
        const sampleStep = 8;
        
        for (let x = 0; x < w; x += sampleStep) {
          const topIdx = (0 * w + x) * 4;
          const botIdx = ((h - 1) * w + x) * 4;
          bgR += d[topIdx] + d[botIdx];
          bgG += d[topIdx + 1] + d[botIdx + 1];
          bgB += d[topIdx + 2] + d[botIdx + 2];
          bgCount += 2;
        }

        for (let y = 0; y < h; y += sampleStep) {
          const leftIdx = (y * w + 0) * 4;
          const rightIdx = (y * w + (w - 1)) * 4;
          bgR += d[leftIdx] + d[rightIdx];
          bgG += d[leftIdx + 1] + d[rightIdx + 1];
          bgB += d[leftIdx + 2] + d[rightIdx + 2];
          bgCount += 2;
        }

        bgR = bgR / bgCount;
        bgG = bgG / bgCount;
        bgB = bgB / bgCount;

        const centerX = w / 2;
        const centerY = h / 2;
        const maxDist = Math.sqrt(centerX * centerX + centerY * centerY);

        let segmentedPixels = 0;
        const totalPixels = w * h;

        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const idx = (y * w + x) * 4;
            const r = d[idx];
            const g = d[idx + 1];
            const b = d[idx + 2];

            const colorDiff = Math.sqrt(
              Math.pow(r - bgR, 2) + Math.pow(g - bgG, 2) + Math.pow(b - bgB, 2)
            );

            const distFromCenter = Math.sqrt(
              Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2)
            );
            const centerProtection = Math.max(0, 1 - distFromCenter / (maxDist * 0.75));
            const threshold = 32 + centerProtection * 35;

            if (colorDiff < threshold && distFromCenter > w * 0.15) {
              d[idx + 3] = 0;
              segmentedPixels++;
            }
          }
        }

        ctx.putImageData(imgData, 0, 0);
        const confidence = Math.min(95, Math.round((segmentedPixels / (totalPixels * 0.6)) * 100));

        resolve({
          success: confidence >= 40,
          resultDataUrl: canvas.toDataURL('image/png'),
          confidence,
        });
      } catch {
        resolve({ success: false, resultDataUrl: imageSrc, confidence: 40 });
      }
    };
    img.onerror = () => resolve({ success: false, resultDataUrl: imageSrc, confidence: 30 });
    img.src = imageSrc;
  });
}
