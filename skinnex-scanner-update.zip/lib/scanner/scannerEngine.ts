import { ProductCategory, ARBodyTarget, CategoryScanProfile, ScanFacetId, ScanFacet, CapturedFrame } from './types';

export const CATEGORY_PROFILES: Record<ProductCategory, CategoryScanProfile> = {
  rings: {
    defaultTarget: 'finger',
    recommendedDistanceCm: 15,
    scaleEstimateMeters: 0.022,
    facets: [
      { id: 'front', label: 'Top / Stone', required: true },
      { id: 'left', label: 'Left Shank', required: true },
      { id: 'right', label: 'Right Shank', required: true },
      { id: 'back', label: 'Inner Circumference', required: false },
      { id: 'bottom', label: 'Under Gallery', required: false },
      { id: 'detail', label: 'Stone Cut / Facets', required: false },
    ],
    guidanceNotes: ['Place on a flat surface or upright ring stand', 'Capture gemstone facet reflections'],
  },
  watches: {
    defaultTarget: 'wrist',
    recommendedDistanceCm: 25,
    scaleEstimateMeters: 0.045,
    facets: [
      { id: 'front', label: 'Dial & Bezel', required: true },
      { id: 'left', label: "Crown / 3 o'clock", required: true },
      { id: 'right', label: "Case Side / 9 o'clock", required: true },
      { id: 'top', label: 'Top Strap / Lugs', required: true },
      { id: 'bottom', label: 'Bottom Strap / Clasp', required: true },
      { id: 'back', label: 'Caseback', required: false },
    ],
    guidanceNotes: ['Keep watch flat or buckled around cushion', 'Avoid bright overhead spot reflections on crystal'],
  },
  bracelets: {
    defaultTarget: 'wrist',
    recommendedDistanceCm: 25,
    scaleEstimateMeters: 0.07,
    facets: [
      { id: 'front', label: 'Top Surface', required: true },
      { id: 'left', label: 'Left Curve', required: true },
      { id: 'right', label: 'Right Curve', required: true },
      { id: 'bottom', label: 'Clasp Area', required: false },
    ],
    guidanceNotes: ['Circle around the bracelet evenly'],
  },
  bangles: {
    defaultTarget: 'wrist',
    recommendedDistanceCm: 20,
    scaleEstimateMeters: 0.065,
    facets: [
      { id: 'front', label: 'Outer Perimeter', required: true },
      { id: 'left', label: 'Side Profile', required: true },
      { id: 'top', label: 'Top Rim', required: true },
      { id: 'back', label: 'Inner Wall', required: false },
    ],
    guidanceNotes: ['Tilt camera 45° to catch both inner and outer edge'],
  },
  earrings: {
    defaultTarget: 'ear',
    recommendedDistanceCm: 15,
    scaleEstimateMeters: 0.035,
    facets: [
      { id: 'front', label: 'Front Drop', required: true },
      { id: 'left', label: 'Side Edge', required: true },
      { id: 'top', label: 'Hook / Post', required: true },
      { id: 'back', label: 'Back Plate', required: false },
    ],
    guidanceNotes: ['Lay flat or hang on an earring display card'],
  },
  necklaces: {
    defaultTarget: 'neck_chest',
    recommendedDistanceCm: 35,
    scaleEstimateMeters: 0.22,
    facets: [
      { id: 'front', label: 'Pendant / Center', required: true },
      { id: 'left', label: 'Left Chain', required: true },
      { id: 'right', label: 'Right Chain', required: true },
      { id: 'bottom', label: 'Clasp', required: false },
    ],
    guidanceNotes: ['Arrange chain in a natural neckline arc'],
  },
  glasses: {
    defaultTarget: 'face',
    recommendedDistanceCm: 30,
    scaleEstimateMeters: 0.14,
    facets: [
      { id: 'front', label: 'Front Frames & Lenses', required: true },
      { id: 'left', label: 'Left Temple & Hinge', required: true },
      { id: 'right', label: 'Right Temple & Hinge', required: true },
      { id: 'top', label: 'Browline & Bridge', required: true },
      { id: 'bottom', label: 'Nosepads', required: false },
    ],
    guidanceNotes: ['Open glasses temples as if worn', 'Keep frame straight and level'],
  },
  shoes: {
    defaultTarget: 'feet',
    recommendedDistanceCm: 45,
    scaleEstimateMeters: 0.28,
    facets: [
      { id: 'front', label: 'Toe Box & Tongue', required: true },
      { id: 'left', label: 'Lateral Side', required: true },
      { id: 'right', label: 'Medial Side', required: true },
      { id: 'back', label: 'Heel Counter', required: true },
      { id: 'top', label: 'Collar & Insole', required: false },
      { id: 'bottom', label: 'Outsole', required: false },
    ],
    guidanceNotes: ['Circle slowly around the entire perimeter of the shoe'],
  },
  bags: {
    defaultTarget: 'hand_shoulder',
    recommendedDistanceCm: 50,
    scaleEstimateMeters: 0.35,
    facets: [
      { id: 'front', label: 'Front Panel & Clasp', required: true },
      { id: 'left', label: 'Left Gusset', required: true },
      { id: 'right', label: 'Right Gusset', required: true },
      { id: 'back', label: 'Back Panel', required: true },
      { id: 'top', label: 'Handles / Opening', required: true },
      { id: 'bottom', label: 'Bottom / Base Feet', required: false },
    ],
    guidanceNotes: ['Stand bag upright on a flat tabletop'],
  },
  clothing: {
    defaultTarget: 'body',
    recommendedDistanceCm: 80,
    scaleEstimateMeters: 0.75,
    facets: [
      { id: 'front', label: 'Front Bodice', required: true },
      { id: 'left', label: 'Left Profile / Sleeve', required: true },
      { id: 'right', label: 'Right Profile / Sleeve', required: true },
      { id: 'back', label: 'Back', required: true },
    ],
    guidanceNotes: ['Hang on a clean neutral hanger or dress form'],
  },
  furniture: {
    defaultTarget: 'room_environment',
    recommendedDistanceCm: 150,
    scaleEstimateMeters: 0.9,
    facets: [
      { id: 'front', label: 'Front Elevation', required: true },
      { id: 'left', label: 'Left Side', required: true },
      { id: 'right', label: 'Right Side', required: true },
      { id: 'back', label: 'Rear Panel', required: true },
      { id: 'top', label: 'Top Surface', required: true },
    ],
    guidanceNotes: ['Allow 1 meter clearance around object to walk around'],
  },
  accessories: {
    defaultTarget: 'object_placement',
    recommendedDistanceCm: 30,
    scaleEstimateMeters: 0.15,
    facets: [
      { id: 'front', label: 'Front', required: true },
      { id: 'left', label: 'Left', required: true },
      { id: 'right', label: 'Right', required: true },
      { id: 'back', label: 'Back', required: true },
      { id: 'top', label: 'Top', required: false },
    ],
    guidanceNotes: ['Rotate phone slowly in a 360 loop around item'],
  },
  beauty: {
    defaultTarget: 'face',
    recommendedDistanceCm: 20,
    scaleEstimateMeters: 0.08,
    facets: [
      { id: 'front', label: 'Product Packaging / Tip', required: true },
      { id: 'left', label: 'Left View', required: true },
      { id: 'right', label: 'Right View', required: true },
      { id: 'top', label: 'Shade / Texture swatch', required: true },
    ],
    guidanceNotes: ['Capture product container and open swatch/color detail'],
  },
  general: {
    defaultTarget: 'object_placement',
    recommendedDistanceCm: 35,
    scaleEstimateMeters: 0.2,
    facets: [
      { id: 'front', label: 'Front View', required: true },
      { id: 'left', label: 'Left View', required: true },
      { id: 'right', label: 'Right View', required: true },
      { id: 'back', label: 'Back View', required: true },
      { id: 'top', label: 'Top View', required: false },
    ],
    guidanceNotes: ['Capture from front, left, right, and back at 45 degree tilt'],
  },
  custom: {
    defaultTarget: 'object_placement',
    recommendedDistanceCm: 35,
    scaleEstimateMeters: 0.2,
    facets: [
      { id: 'front', label: 'Primary View', required: true },
      { id: 'left', label: 'Left Side', required: true },
      { id: 'right', label: 'Right Side', required: true },
      { id: 'back', label: 'Reverse Side', required: true },
      { id: 'top', label: 'Top View', required: false },
    ],
    guidanceNotes: ['Move around the object slowly in a continuous circle'],
  },
};

export function evaluateFrameQuality(ctx: CanvasRenderingContext2D, width: number, height: number): {
  score: number;
  level: 'HIGH' | 'MEDIUM' | 'LOW';
} {
  const sampleW = Math.min(width, 160);
  const sampleH = Math.min(height, 120);
  const imageData = ctx.getImageData(0, 0, sampleW, sampleH);
  const data = imageData.data;

  let totalLuminance = 0;
  let edgeEnergy = 0;

  for (let y = 1; y < sampleH - 1; y += 2) {
    for (let x = 1; x < sampleW - 1; x += 2) {
      const idx = (y * sampleW + x) * 4;
      const lum = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
      totalLuminance += lum;

      const idxRight = (y * sampleW + (x + 1)) * 4;
      const idxDown = ((y + 1) * sampleW + x) * 4;
      const lumRight = 0.299 * data[idxRight] + 0.587 * data[idxRight + 1] + 0.114 * data[idxRight + 2];
      const lumDown = 0.299 * data[idxDown] + 0.587 * data[idxDown + 1] + 0.114 * data[idxDown + 2];

      edgeEnergy += Math.abs(lum - lumRight) + Math.abs(lum - lumDown);
    }
  }

  const sampleCount = (sampleH / 2) * (sampleW / 2);
  const avgLum = totalLuminance / sampleCount;
  const avgEdge = edgeEnergy / sampleCount;

  const lightPenalty = avgLum < 30 || avgLum > 230 ? 30 : avgLum < 60 ? 15 : 0;
  const sharpnessScore = Math.min(70, avgEdge * 3.5);
  const finalScore = Math.max(15, Math.min(98, Math.round(sharpnessScore + 30 - lightPenalty)));

  let level: 'HIGH' | 'MEDIUM' | 'LOW' = 'MEDIUM';
  if (finalScore >= 70) level = 'HIGH';
  else if (finalScore < 40) level = 'LOW';

  return { score: finalScore, level };
}

export function determineActiveFacet(
  azimuthDeg: number,
  pitchDeg: number,
  category: ProductCategory
): ScanFacetId {
  if (pitchDeg < -35) return 'top';
  if (pitchDeg > 45) return 'bottom';

  const normAz = ((azimuthDeg % 360) + 360) % 360;
  if (normAz >= 315 || normAz < 45) return 'front';
  if (normAz >= 45 && normAz < 135) return 'right';
  if (normAz >= 135 && normAz < 225) return 'back';
  return 'left';
}

export function computeCoverageAndGuidance(
  facets: ScanFacet[],
  frames: CapturedFrame[]
): {
  totalCoverage: number;
  updatedFacets: ScanFacet[];
  guidanceText: string;
  direction: 'left' | 'right' | 'higher' | 'lower' | 'downward' | 'back' | 'closer' | 'away' | 'steady';
  progressiveStage: 25 | 50 | 75 | 90 | 100;
  stageLabel: string;
  canCreateAnyway: boolean;
} {
  const facetCounts: Record<ScanFacetId, { count: number; maxQuality: number }> = {
    front: { count: 0, maxQuality: 0 },
    left: { count: 0, maxQuality: 0 },
    right: { count: 0, maxQuality: 0 },
    back: { count: 0, maxQuality: 0 },
    top: { count: 0, maxQuality: 0 },
    bottom: { count: 0, maxQuality: 0 },
    detail: { count: 0, maxQuality: 0 },
  };

  frames.forEach((f) => {
    if (facetCounts[f.facet]) {
      facetCounts[f.facet].count += 1;
      facetCounts[f.facet].maxQuality = Math.max(facetCounts[f.facet].maxQuality, f.qualityScore);
    }
  });

  const updatedFacets: ScanFacet[] = facets.map((facet) => {
    const data = facetCounts[facet.id];
    let cov = 0;
    let status: ScanFacet['status'] = 'not_captured';

    if (data && data.count > 0) {
      if (data.count === 1) {
        cov = Math.min(65, Math.round(data.maxQuality * 0.65));
        status = cov > 50 ? 'partial' : 'partial';
      } else {
        cov = Math.min(100, Math.round(50 + data.count * 15 + data.maxQuality * 0.25));
        status = cov >= 80 ? 'captured' : 'partial';
      }
    } else {
      const oppId = facet.id === 'back' ? 'front' : facet.id === 'right' ? 'left' : null;
      if (oppId && facetCounts[oppId]?.count >= 2) {
        cov = 45;
        status = 'reconstructed';
      }
    }

    return {
      ...facet,
      coverage: Math.min(100, cov),
      status,
    };
  });

  const requiredFacets = updatedFacets.filter((f) => f.required);
  const requiredSum = requiredFacets.reduce((acc, f) => acc + f.coverage, 0);
  const totalCoverage = Math.min(
    100,
    Math.round(requiredSum / Math.max(1, requiredFacets.length))
  );

  let guidanceText = 'Move slowly around the product';
  let direction: 'left' | 'right' | 'higher' | 'lower' | 'downward' | 'back' | 'closer' | 'away' | 'steady' = 'left';

  const lowestFacet = [...updatedFacets]
    .filter((f) => f.required)
    .sort((a, b) => a.coverage - b.coverage)[0];

  if (lowestFacet && lowestFacet.coverage < 70) {
    if (lowestFacet.id === 'left') {
      guidanceText = 'Move phone around to the LEFT side';
      direction = 'left';
    } else if (lowestFacet.id === 'right') {
      guidanceText = 'Move phone around to the RIGHT side';
      direction = 'right';
    } else if (lowestFacet.id === 'back') {
      guidanceText = 'Circle around to capture the BACK';
      direction = 'back';
    } else if (lowestFacet.id === 'top') {
      guidanceText = 'Tilt your phone slightly DOWNWARD';
      direction = 'downward';
    } else if (lowestFacet.id === 'bottom') {
      guidanceText = 'Angle camera slightly UPWARD to capture underside';
      direction = 'higher';
    }
  } else if (totalCoverage >= 80) {
    guidanceText = '✓ Excellent scan coverage captured';
    direction = 'steady';
  }

  let progressiveStage: 25 | 50 | 75 | 90 | 100 = 25;
  let stageLabel = 'Initial shape detected';

  if (totalCoverage >= 95) {
    progressiveStage = 100;
    stageLabel = 'AR model ready';
  } else if (totalCoverage >= 80) {
    progressiveStage = 90;
    stageLabel = 'Synthesizing details & missing areas';
  } else if (totalCoverage >= 60) {
    progressiveStage = 75;
    stageLabel = 'Improving surface detail & textures';
  } else if (totalCoverage >= 35) {
    progressiveStage = 50;
    stageLabel = 'Building 3D geometry & depth';
  }

  const canCreateAnyway = totalCoverage >= 45 || frames.length >= 3;

  return {
    totalCoverage,
    updatedFacets,
    guidanceText,
    direction,
    progressiveStage,
    stageLabel,
    canCreateAnyway,
  };
}
